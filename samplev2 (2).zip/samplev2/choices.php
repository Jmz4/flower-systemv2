<?php
require_once 'config.php';

$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');
$orderCount = 0;
$isLoggedIn = isset($_SESSION['user_id']);

// Redirect non-logged-in users to welcome page
if (!$isLoggedIn) {
    header('Location: welcome.php');
    exit;
}

if ($isLoggedIn) {
    $userId = intval($_SESSION['user_id']);
    $orderCountSql = "SELECT COUNT(*) AS count FROM orders WHERE user_id = ?";
    $orderCountStmt = $conn->prepare($orderCountSql);
    $orderCountStmt->bind_param('i', $userId);
    $orderCountStmt->execute();
    $orderCountResult = $orderCountStmt->get_result();
    $orderCountRow = $orderCountResult->fetch_assoc();
    $orderCount = $orderCountRow['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }

        .choices-container {
            max-width: 1000px;
            margin: 3rem auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            padding: 0 1rem;
        }

        .choice-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 3rem 2rem;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .choice-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 16px 48px rgba(102, 126, 234, 0.3);
            border-color: #667eea;
        }

        .choice-card h2 {
            color: #667eea;
            font-size: 2rem;
            margin-bottom: 1rem;
            border: none;
            padding: 0;
        }

        .choice-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
            display: block;
        }

        .choice-card p {
            color: #555;
            line-height: 1.8;
            margin-bottom: 2rem;
            font-size: 1.05rem;
        }

        .choice-button {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .choice-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
        }

        .choices-header {
            text-align: center;
            margin-bottom: 2rem;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        .choices-header h1 {
            color: #667eea;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .choices-header p {
            color: #666;
            font-size: 1.1rem;
            margin: 0;
        }

        @media (max-width: 768px) {
            .choices-container {
                grid-template-columns: 1fr;
                gap: 2rem;
                margin: 2rem auto;
            }

            .choice-card {
                padding: 2rem 1.5rem;
            }

            .choice-card h2 {
                font-size: 1.5rem;
            }

            .choice-icon {
                font-size: 3rem;
                margin-bottom: 1rem;
            }

            .choices-header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="choices.php">Home</a></li>
                    <li><a href="reviews.php">Reviews</a></li>
                    <li><a href="about.php">About</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="myorders.php">My Orders <span id="order-count"><?php echo $orderCount; ?></span></a></li>
                    <?php endif; ?>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if ($isLoggedIn): ?>
                        <?php if (isAdminOrStaff()): ?>
                            <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                        <?php endif; ?>
                        <li><a href="logout.php">Logout</a></li>
                        <li class="nav-user">Welcome, <?php echo $username; ?></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <section class="choices-header">
            <h1>🌸 What Would You Like to Do?</h1>
            <p>Choose between browsing our beautiful pre-designed bouquets or creating your own custom arrangement</p>
        </section>

        <div class="choices-container">
            <!-- Option 1: Pre-Designed Bouquets -->
            <a href="bouquets.php" class="choice-card">
                <span class="choice-icon">💐</span>
                <h2>Pre-Designed Bouquets</h2>
                <p>Explore our handcrafted collection of beautiful, ready-made flower arrangements. Perfect for any occasion and delivered fresh to your door.</p>
                <button class="choice-button">Browse Bouquets</button>
            </a>

            <!-- Option 2: Custom Arrangement -->
            <a href="custom.php" class="choice-card">
                <span class="choice-icon">🎨</span>
                <h2>Create Custom Arrangement</h2>
                <p>Design your own unique flower arrangement! Drag and drop your favorite flowers and choose the perfect base for a truly personalized gift.</p>
                <button class="choice-button">Create Custom</button>
            </a>
        </div>

        <section class="review-callout" style="margin-top: 3rem;">
            <p>Want to know why customers love L&C Flowershop? <a href="reviews.php">Read our customer reviews</a> and see real stories from happy clients.</p>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 L&C Flowershop. All rights reserved. | Contact: info@flowershop.com</p>
    </footer>

    <script>
        window.cartUserKey = <?php echo json_encode($isLoggedIn ? 'cart_user_' . intval($_SESSION['user_id']) : 'cart_guest'); ?>;
    </script>
    <script src="script.js?v=2"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            updateCartCount();
        });
    </script>
</body>
</html>
