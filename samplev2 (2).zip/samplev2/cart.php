<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        html, body {
            min-height: 100%;
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') no-repeat center center fixed !important;
            background-size: cover !important;
            color: white;
        }

        main.container {
            background: transparent !important;
        }

        .navbar, footer {
            background: rgba(0, 0, 0, 0.55) !important;
        }

        .cart-container,
        .checkout-form,
        .order-summary {
            background: rgba(255, 255, 255, 0.94) !important;
            color: #333 !important;
        }

        .cart-container h2,
        .checkout-form h3,
        .order-summary h3,
        .cart-item h4,
        .summary-row,
        .form-group label {
            color: #333 !important;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="myorders.php">My Orders</a></li>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if (isAdminOrStaff()): ?>
                        <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                    <li class="nav-user">Welcome, <?php echo $username; ?></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <h1 style="color: #667eea; margin-bottom: 1rem;">Shopping Cart</h1>

        <div class="cart-grid">
            <!-- Cart Items -->
            <div class="cart-container">
                <h2>Your Items</h2>
                <div id="cartItems" class="items-list"></div>
                <div style="margin-top: 1rem;">
                    <button onclick="clearCart()" class="btn btn-danger">Clear Cart</button>
                    <button onclick="window.location.href='index.php'" class="btn btn-primary">Continue Shopping</button>
                </div>
            </div>

            <!-- Checkout Form -->
            <div id="orderSummary" style="display:none;">
                <div class="checkout-form">
                    <h3>Delivery Details</h3>
                    <form id="checkoutForm" onsubmit="event.preventDefault(); checkout();">
                        <div class="form-group">
                            <label for="customerName">Full Name *</label>
                            <input type="text" id="customerName" required>
                        </div>

                        <div class="form-group">
                            <label for="customerEmail">Email *</label>
                            <input type="email" id="customerEmail" required>
                        </div>

                        <div class="form-group">
                            <label for="customerPhone">Phone Number *</label>
                            <input type="text" id="customerPhone" placeholder="e.g., 09XX-XXX-XXXX" required>
                        </div>

                        <div class="form-group">
                            <label for="customerAddress">Delivery Address *</label>
                            <textarea id="customerAddress" rows="3" required></textarea>
                        </div>

                        <div class="form-group">
                            <label for="orderType">Order Type *</label>
                            <select id="orderType" required>
                                <option value="delivery">Delivery</option>
                                <option value="pickup">Pickup</option>
                            </select>
                        </div>

                        <div class="order-summary">
                            <h3>Order Summary</h3>
                            <div class="summary-row">
                                <span>Subtotal:</span>
                                <span id="cartSubtotal">₱0.00</span>
                            </div>
                            <div class="summary-row total">
                                <span>Total:</span>
                                <span id="cartTotal">₱0.00</span>
                            </div>
                            <input type="hidden" id="checkoutTotal">
                        </div>

                        <button type="submit" class="btn btn-success btn-full" style="margin-top: 1rem; font-size: 1.1rem;">Place Order</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Flower Shop. All rights reserved. | Contact: info@flowershop.com</p>
    </footer>

    <script>
        window.cartUserKey = <?php echo json_encode('cart_user_' . intval($_SESSION['user_id'])); ?>;
    </script>
    <script src="script.js?v=2"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            displayCart();
            updateCartCount();
        });
    </script>
</body>
</html>
