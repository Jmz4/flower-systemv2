<?php
$conn = new mysqli('localhost', 'root', '');
$conn->select_db('flower_shop');
$result = $conn->query('SELECT name, price FROM bouquets');
while ($row = $result->fetch_assoc()) {
    echo $row['name'] . ': ₱' . $row['price'] . PHP_EOL;
}
$conn->close();
?>