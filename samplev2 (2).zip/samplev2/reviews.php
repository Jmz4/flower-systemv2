<?php
require_once 'config.php';

$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');
$orderCount = 0;
$isLoggedIn = isset($_SESSION['user_id']);

if ($isLoggedIn) {
    $userId = intval($_SESSION['user_id']);
    $orderCountSql = "SELECT COUNT(*) AS count FROM orders WHERE user_id = ?";
    $orderCountStmt = $conn->prepare($orderCountSql);
    $orderCountStmt->bind_param('i', $userId);
    $orderCountStmt->execute();
    $orderCountResult = $orderCountStmt->get_result();
    $orderCountRow = $orderCountResult->fetch_assoc();
    $orderCount = $orderCountRow['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews - L&C Flowershop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="reviews.php">Reviews</a></li>
                    <li><a href="about.php">About</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="myorders.php">My Orders <span id="order-count"><?php echo $orderCount; ?></span></a></li>
                    <?php endif; ?>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if ($isLoggedIn): ?>
                        <?php if (isAdminOrStaff()): ?>
                            <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                        <?php endif; ?>
                        <li><a href="logout.php">Logout</a></li>
                        <li class="nav-user">Welcome, <?php echo $username; ?></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <section class="customer-reviews">
            <h2>Customer Reviews</h2>
            <div class="review-grid">
                <article class="review-card">
                    <p class="review-text">“L&C Flowershop made our anniversary celebration unforgettable. The flowers were stunning and the arrangement felt personal and elegant. Delivery was on time and the entire experience was seamless.”</p>
                    <div class="review-footer">
                        <strong>Sarah & James</strong>
                        <span>10th Anniversary</span>
                    </div>
                </article>
                <article class="review-card review-highlight">
                    <p class="review-text">“I hired L&C Flowershop for an event, and the bouquets were breathtaking. The team matched our theme perfectly, and the blooms lasted all night. I will recommend them more.”</p>
                    <div class="review-footer">
                        <strong>Michael Rodriguez</strong>
                        <span>Event Coordinator, City Arts</span>
                    </div>
                </article>
                <article class="review-card">
                    <p class="review-text">“The Get Well bouquet from L&C Flowershop brightened my sister's day. Beautiful colors, fresh flowers, and thoughtful service made it a wonderful gift.”</p>
                    <div class="review-footer">
                        <strong>Isabella Green</strong>
                        <span>Happy Customer</span>
                    </div>
                </article>
            </div>
        </section>
    </main>

</body>
</html>
