<?php
// Database setup script - Run once to create tables
$conn = new mysqli('localhost', 'root', '');

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS flower_shop";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}

$conn->select_db('flower_shop');

// Create users table
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    is_admin INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Create audit_logs table (used for action logging)
$sql = "CREATE TABLE IF NOT EXISTS audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";
$conn->query($sql);

// Create bases table
$sql = "CREATE TABLE IF NOT EXISTS bases (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) UNIQUE NOT NULL,
    price DECIMAL(10, 2) NOT NULL
)";
$conn->query($sql);

// Create flowers table
$sql = "CREATE TABLE IF NOT EXISTS flowers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) UNIQUE NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 100,
    image VARCHAR(255)
)";
$conn->query($sql);

// Create pre-designed bouquets table
$sql = "CREATE TABLE IF NOT EXISTS bouquets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    base_id INT NOT NULL,
    image VARCHAR(255),
    FOREIGN KEY (base_id) REFERENCES bases(id)
)";
$conn->query($sql);

// Create bouquet items table (flowers in each bouquet)
$sql = "CREATE TABLE IF NOT EXISTS bouquet_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bouquet_id INT NOT NULL,
    flower_id INT NOT NULL,
    quantity INT NOT NULL,
    UNIQUE KEY uq_bouquet_flower (bouquet_id, flower_id),
    FOREIGN KEY (bouquet_id) REFERENCES bouquets(id) ON DELETE CASCADE,
    FOREIGN KEY (flower_id) REFERENCES flowers(id)
)";
$conn->query($sql);

// Create orders table
$sql = "CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_address TEXT NOT NULL,
    order_type ENUM('delivery', 'pickup') DEFAULT 'delivery',
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";
$conn->query($sql);

// Temporarily allow both legacy and new values while converting the remaining rows.
$conn->query("ALTER TABLE orders MODIFY status ENUM('pending', 'confirmed', 'preparing', 'Preparing to Ship', 'out for delivery', 'delivered', 'cancelled', 'completed', 'Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled') DEFAULT 'Pending'");
$conn->query("UPDATE orders SET status = 'delivered' WHERE status = 'completed'");
$conn->query("UPDATE orders SET status = 'preparing' WHERE status = 'Preparing to Ship'");
$conn->query("UPDATE orders SET status = 'Pending' WHERE status = 'pending'");
$conn->query("UPDATE orders SET status = 'Confirmed' WHERE status = 'confirmed'");
$conn->query("UPDATE orders SET status = 'Preparing' WHERE status = 'preparing'");
$conn->query("UPDATE orders SET status = 'Out for Delivery' WHERE status = 'out for delivery'");
$conn->query("UPDATE orders SET status = 'Delivered' WHERE status = 'delivered'");
$conn->query("UPDATE orders SET status = 'Cancelled' WHERE status = 'cancelled'");
$conn->query("ALTER TABLE orders MODIFY status ENUM('Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled') DEFAULT 'Pending'");

// Create order items table
$sql = "CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    item_type ENUM('flower', 'bouquet') NOT NULL,
    flower_id INT,
    bouquet_id INT,
    base_id INT,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (flower_id) REFERENCES flowers(id),
    FOREIGN KEY (bouquet_id) REFERENCES bouquets(id),
    FOREIGN KEY (base_id) REFERENCES bases(id)
)";
$conn->query($sql);

// Store the custom arrangement brief on the base row for each order.
$customColumns = [
    'custom_style' => "VARCHAR(30) NULL",
    'custom_notes' => "TEXT NULL",
    'inspiration_image' => "VARCHAR(255) NULL",
    'waiver_agreed' => "TINYINT(1) NOT NULL DEFAULT 0"
];
foreach ($customColumns as $column => $definition) {
    $columnCheck = $conn->query("SHOW COLUMNS FROM order_items LIKE '" . $conn->real_escape_string($column) . "'");
    if ($columnCheck && $columnCheck->num_rows === 0) {
        $conn->query("ALTER TABLE order_items ADD COLUMN `$column` $definition");
    }
}

// Remove duplicate records by name before seeding sample data
$conn->query("DELETE b1 FROM bases b1 INNER JOIN bases b2 WHERE b1.id > b2.id AND b1.name = b2.name");
$conn->query("DELETE f1 FROM flowers f1 INNER JOIN flowers f2 WHERE f1.id > f2.id AND f1.name = f2.name");
$conn->query("DELETE q1 FROM bouquets q1 INNER JOIN bouquets q2 WHERE q1.id > q2.id AND q1.name = q2.name");
$conn->query("DELETE bi1 FROM bouquet_items bi1 INNER JOIN bouquet_items bi2 ON bi1.bouquet_id = bi2.bouquet_id AND bi1.flower_id = bi2.flower_id WHERE bi1.id > bi2.id");

// Ensure unique names for bases, flowers, bouquets and bouquet items.
$uniqueIndexes = [
    ['bases', 'unique_base_name', 'name'],
    ['flowers', 'unique_flower_name', 'name'],
    ['bouquets', 'unique_bouquet_name', 'name'],
    ['bouquet_items', 'uq_bouquet_flower', 'bouquet_id, flower_id']
];
foreach ($uniqueIndexes as [$table, $index, $columns]) {
    $indexCheck = $conn->query("SHOW INDEX FROM `$table` WHERE Key_name = '" . $conn->real_escape_string($index) . "'");
    if ($indexCheck && $indexCheck->num_rows === 0) {
        $conn->query("ALTER TABLE `$table` ADD UNIQUE KEY `$index` ($columns)");
    }
}

// Insert sample data - Bases
$bases = [
    ['Bouquet', 100.00],
    ['Vase', 150.00],
    ['Box', 50.00]
];

foreach ($bases as $base) {
    $sql = "INSERT INTO bases (name, price) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE price = VALUES(price)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sd", $base[0], $base[1]);
    $stmt->execute();
}

// Insert sample data - Flowers
$flowers = [
    ['Rose', 50.50, 100],
    ['Tulip', 55.80, 150],
    ['Sunflower', 250.00, 80],
    ['Daisy', 30.50, 120],
    ['Lily', 60.00, 90],
    ['Orchid', 70.00, 60],
    ['Carnation', 80.20, 200],
    ['Lavender', 50.20, 110]
];

foreach ($flowers as $flower) {
    $sql = "INSERT INTO flowers (name, price, stock) VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE price = VALUES(price), stock = VALUES(stock)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdi", $flower[0], $flower[1], $flower[2]);
    $stmt->execute();
}

// Insert pre-designed bouquets
$bouquets = [
    ['Romantic Love Bouquet', 'Red roses for that special someone', 1499.00, 1],
    ['Happy Birthday Bouquet', 'Colorful mixed flowers for celebrations', 999.00, 1],
    ['Sympathy Bouquet', 'White and soft colored flowers', 1299.00, 2]
];

foreach ($bouquets as $bouquet) {
    $sql = "INSERT INTO bouquets (name, description, price, base_id) VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE description = VALUES(description), price = VALUES(price), base_id = VALUES(base_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdi", $bouquet[0], $bouquet[1], $bouquet[2], $bouquet[3]);
    $stmt->execute();
}

// Insert bouquet items
$bouquet_items = [
    [1, 1, 12], // Romantic: 12 Roses
    [1, 5, 5],  // Romantic: 5 Lilies
    [2, 1, 8],  // Birthday: 8 Roses
    [2, 2, 6],  // Birthday: 6 Tulips
    [2, 3, 5],  // Birthday: 5 Sunflowers
    [3, 5, 10], // Sympathy: 10 Lilies
    [3, 4, 8]   // Sympathy: 8 Daisies
];

foreach ($bouquet_items as $item) {
    $sql = "INSERT INTO bouquet_items (bouquet_id, flower_id, quantity) VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $item[0], $item[1], $item[2]);
    $stmt->execute();
}

// Insert sample admin user (ignore if already exists)
$username = 'admin';
$password = password_hash('admin123', PASSWORD_BCRYPT);
$email = 'admin@flowershop.com';
$sql = "INSERT INTO users (username, password, email, is_admin) VALUES (?, ?, ?, 1)
        ON DUPLICATE KEY UPDATE password = VALUES(password), email = VALUES(email), is_admin = VALUES(is_admin)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $password, $email);
$stmt->execute();

echo "Database setup completed successfully!<br>";

$conn->close();
?>
