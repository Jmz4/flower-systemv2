<?php
$conn = new mysqli('localhost', 'root', '');
$conn->select_db('flower_shop');

$conn->query('DELETE FROM order_items');
$conn->query('DELETE FROM bouquet_items');
$conn->query('DELETE FROM bouquets');
$conn->query('DELETE FROM flowers');
$conn->query('DELETE FROM bases');
$conn->query('DELETE FROM orders');
$conn->query('DELETE FROM users');

echo 'Database cleared successfully';
$conn->close();
?>