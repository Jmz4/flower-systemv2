// Global variables
let arrangement = {
    base: null,
    basePrice: 0,
    flowers: []
};

let allFlowers = []; // Store all available flowers for drag-drop

function getCartStorageKey() {
    const key = window.cartUserKey || 'cart_guest';

    // Migrate legacy shared cart data to the per-user cart key when needed.
    if (key !== 'cart' && localStorage.getItem(key) === null && localStorage.getItem('cart') !== null) {
        localStorage.setItem(key, localStorage.getItem('cart'));
        localStorage.removeItem('cart');
    }

    return key;
}

// Get flower image path based on flower name
function getFlowerImagePath(flowerName) {
    const imageMap = {
        'Rose': './flowerimage/flowersrose.jfif',
        'Tulip': './flowerimage/flowerstulip.jfif',
        'Sunflower': './flowerimage/flowerssunflower.jfif',
        'Daisy': './flowerimage/flowersdaisy.jfif',
        'Lily': './flowerimage/flowerslily.jfif',
        'Orchid': './flowerimage/flowersorchid.jfif',
        'Carnation': './flowerimage/flowerscarnation.jfif',
        'Lavender': './flowerimage/flowerslavender.jfif'
    };
    return imageMap[flowerName] || './flowerimage/flowersrose.jfif';
}

function getBouquetImageSrc(bouquetName) {
    const bouquetImageMap = {
        'Romantic Love Bouquet': './flowerimage/Romantic Love Bouquet (3).jfif',
        'Happy Birthday Bouquet': './flowerimage/Happy Birthday Bouquet.jfif',
        'Sympathy Bouquet': './flowerimage/Sympathy Bouquet.jfif'
    };
    return bouquetImageMap[bouquetName] || './flowerimage/flowersrose.jfif';
}

// Generate SVG flower based on flower name
function getFlowerSVG(flowerName) {
    const svgs = {
        'Rose': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="8" fill="#d4443f"/>
            <circle cx="50" cy="35" r="7" fill="#e74c3c"/>
            <circle cx="40" cy="42" r="6" fill="#c0392b"/>
            <circle cx="60" cy="42" r="6" fill="#c0392b"/>
            <circle cx="45" cy="48" r="5" fill="#e74c3c"/>
            <circle cx="55" cy="48" r="5" fill="#e74c3c"/>
            <path d="M 50 58 Q 45 70 45 85 Q 45 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 50 58 Q 55 70 55 85 Q 55 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <ellipse cx="40" cy="75" rx="4" ry="8" fill="#27ae60"/>
            <ellipse cx="60" cy="72" rx="4" ry="8" fill="#27ae60"/>
        </svg>`,
        'Tulip': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <path d="M 50 20 Q 40 35 40 50 Q 40 60 50 65 Q 60 60 60 50 Q 60 35 50 20" fill="#e74c3c"/>
            <path d="M 40 50 Q 35 60 35 75 Q 35 85 40 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 60 50 Q 65 60 65 75 Q 65 85 60 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <ellipse cx="35" cy="72" rx="3" ry="6" fill="#27ae60"/>
            <ellipse cx="65" cy="70" rx="3" ry="6" fill="#27ae60"/>
        </svg>`,
        'Sunflower': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="12" fill="#f39c12"/>
            <circle cx="50" cy="25" r="6" fill="#f1c40f"/>
            <circle cx="65" cy="35" r="6" fill="#f1c40f"/>
            <circle cx="70" cy="50" r="6" fill="#f1c40f"/>
            <circle cx="65" cy="65" r="6" fill="#f1c40f"/>
            <circle cx="50" cy="75" r="6" fill="#f1c40f"/>
            <circle cx="35" cy="65" r="6" fill="#f1c40f"/>
            <circle cx="30" cy="50" r="6" fill="#f1c40f"/>
            <circle cx="35" cy="35" r="6" fill="#f1c40f"/>
            <path d="M 50 56 Q 45 70 45 85 Q 45 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 50 56 Q 55 70 55 85 Q 55 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
        </svg>`,
        'Daisy': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="8" fill="#f1c40f"/>
            <ellipse cx="50" cy="28" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1"/>
            <ellipse cx="62" cy="35" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(45 62 35)"/>
            <ellipse cx="72" cy="50" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(90 72 50)"/>
            <ellipse cx="62" cy="65" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(135 62 65)"/>
            <ellipse cx="50" cy="72" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(180 50 72)"/>
            <ellipse cx="38" cy="65" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(225 38 65)"/>
            <ellipse cx="28" cy="50" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(270 28 50)"/>
            <ellipse cx="38" cy="35" rx="4" ry="8" fill="white" stroke="#ddd" stroke-width="1" transform="rotate(315 38 35)"/>
            <path d="M 50 58 Q 45 70 45 85 Q 45 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
        </svg>`,
        'Lily': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <path d="M 50 20 Q 35 35 35 50 Q 35 60 50 70" fill="white" stroke="#ddd" stroke-width="1"/>
            <path d="M 50 20 Q 65 35 65 50 Q 65 60 50 70" fill="white" stroke="#ddd" stroke-width="1"/>
            <path d="M 50 20 L 50 70" stroke="#e74c3c" stroke-width="2"/>
            <circle cx="45" cy="45" r="3" fill="#f39c12"/>
            <circle cx="50" cy="48" r="3" fill="#f39c12"/>
            <circle cx="55" cy="45" r="3" fill="#f39c12"/>
            <path d="M 50 70 Q 45 80 45 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 50 70 Q 55 80 55 90" stroke="#27ae60" stroke-width="2" fill="none"/>
        </svg>`,
        'Orchid': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="50" cy="40" rx="8" ry="12" fill="#9b59b6"/>
            <ellipse cx="35" cy="55" rx="6" ry="10" fill="#8e44ad"/>
            <ellipse cx="65" cy="55" rx="6" ry="10" fill="#8e44ad"/>
            <ellipse cx="50" cy="65" rx="7" ry="9" fill="#a569bd"/>
            <circle cx="50" cy="48" r="3" fill="#f1c40f"/>
            <path d="M 50 74 Q 45 82 45 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 50 74 Q 55 82 55 90" stroke="#27ae60" stroke-width="2" fill="none"/>
        </svg>`,
        'Carnation': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="35" r="10" fill="#e74c3c"/>
            <circle cx="45" cy="25" r="5" fill="#c0392b"/>
            <circle cx="55" cy="25" r="5" fill="#c0392b"/>
            <circle cx="40" cy="40" r="5" fill="#c0392b"/>
            <circle cx="60" cy="40" r="5" fill="#c0392b"/>
            <circle cx="45" cy="50" r="4" fill="#e74c3c"/>
            <circle cx="55" cy="50" r="4" fill="#e74c3c"/>
            <path d="M 50 54 Q 45 70 45 85 Q 45 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 50 54 Q 55 70 55 85 Q 55 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
        </svg>`,
        'Lavender': `<svg viewBox="0 0 100 100" width="60" height="60" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="25" r="3" fill="#8e44ad"/>
            <circle cx="45" cy="32" r="3" fill="#8e44ad"/>
            <circle cx="55" cy="32" r="3" fill="#8e44ad"/>
            <circle cx="42" cy="40" r="3" fill="#9b59b6"/>
            <circle cx="58" cy="40" r="3" fill="#9b59b6"/>
            <circle cx="50" cy="45" r="3" fill="#9b59b6"/>
            <circle cx="40" cy="52" r="3" fill="#a569bd"/>
            <circle cx="60" cy="52" r="3" fill="#a569bd"/>
            <circle cx="50" cy="60" r="3" fill="#a569bd"/>
            <path d="M 50 63 Q 48 75 48 85 Q 48 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
            <path d="M 50 63 Q 52 75 52 85 Q 52 90 50 90" stroke="#27ae60" stroke-width="2" fill="none"/>
        </svg>`
    };
    
    return svgs[flowerName] || svgs['Daisy'];
}

// Load bases from server
async function loadBases() {
    try {
        const response = await fetch('api.php?action=getBases');
        const bases = await response.json();
        
        const baseSelect = document.getElementById('base');
        bases.forEach(base => {
            const option = document.createElement('option');
            option.value = base.id;
            option.textContent = `${base.name} (₱${parseFloat(base.price).toFixed(2)})`;
            option.dataset.price = base.price;
            baseSelect.appendChild(option);
        });
        sanitizeCurrencySymbols();
    } catch (error) {
        console.error('Error loading bases:', error);
    }
}

// Load flowers from server and create draggable gallery
async function loadFlowers() {
    try {
        const response = await fetch('api.php?action=getFlowers');
        const flowers = await response.json();
        allFlowers = flowers;
        
        const flowerGallery = document.getElementById('flowerGallery');
        flowerGallery.innerHTML = '';
        
        flowers.forEach(flower => {
            const flowerCard = document.createElement('div');
            flowerCard.className = 'flower-card draggable';
            flowerCard.draggable = true;
            flowerCard.dataset.flowerId = flower.id;
            flowerCard.dataset.flowerName = flower.name;
            flowerCard.dataset.flowerPrice = flower.price;
            flowerCard.dataset.flowerStock = flower.stock;
            
            // Get flower image path
            const flowerImagePath = getFlowerImagePath(flower.name);
            
            flowerCard.innerHTML = `
                <div style="width: 100%; height: 120px; overflow: hidden; border-radius: 6px; margin-bottom: 0.5rem; background: #f5f5f5; display: flex; align-items: center; justify-content: center;">
                    <img src="${flowerImagePath}" alt="${flower.name}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/%3E%3Ctext x=%2250%22 y=%2250%22 text-anchor=%22middle%22 dy=%22.3em%22 font-size=%2220%22 fill=%22%23999%22%3ENo Image%3C/text%3E%3C/svg%3E'">
                </div>
                <div class="flower-name">${flower.name}</div>
                <div class="flower-price">₱${parseFloat(flower.price).toFixed(2)}</div>
                <div class="flower-stock">Stock: ${flower.stock}</div>
            `;
            
            // Add drag event listeners
            flowerCard.addEventListener('dragstart', handleDragStart);
            flowerCard.addEventListener('dragend', handleDragEnd);
            
            flowerGallery.appendChild(flowerCard);
        });
    } catch (error) {
        console.error('Error loading flowers:', error);
    }
}

// Drag event handlers
function handleDragStart(e) {
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('flowerId', this.dataset.flowerId);
    e.dataTransfer.setData('flowerName', this.dataset.flowerName);
    e.dataTransfer.setData('flowerPrice', this.dataset.flowerPrice);
    e.dataTransfer.setData('flowerStock', this.dataset.flowerStock);
    this.classList.add('dragging');
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
}

function sanitizeCurrencySymbols() {
    const nodes = [
        ...document.querySelectorAll('.flower-price, .bouquet-price, .price-display, .item-details, .price-row span, #base option')
    ];
    nodes.forEach(node => {
        if (node && node.textContent.includes('$')) {
            node.textContent = node.textContent.replace(/\$/g, '₱');
        }
    });
}

// Setup drop zone
function setupDropZone() {
    const canvas = document.getElementById('arrangementCanvas');
    
    canvas.addEventListener('dragover', handleDragOver);
    canvas.addEventListener('drop', handleDrop);
    canvas.addEventListener('dragleave', handleDragLeave);
}

function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    document.getElementById('arrangementCanvas').classList.add('drag-over');
}

function handleDragLeave(e) {
    if (e.target.id === 'arrangementCanvas') {
        document.getElementById('arrangementCanvas').classList.remove('drag-over');
    }
}

function handleDrop(e) {
    e.preventDefault();
    document.getElementById('arrangementCanvas').classList.remove('drag-over');
    
    if (!arrangement.base) {
        alert('Please select a base first!');
        return;
    }
    
    const flowerId = e.dataTransfer.getData('flowerId');
    const flowerName = e.dataTransfer.getData('flowerName');
    const flowerPrice = parseFloat(e.dataTransfer.getData('flowerPrice'));
    const flowerStock = parseInt(e.dataTransfer.getData('flowerStock'));
    
    // Check if flower already exists in arrangement
    const existingFlower = arrangement.flowers.find(f => f.id === parseInt(flowerId));
    
    if (existingFlower) {
        // Increase quantity
        existingFlower.quantity += 1;
    } else {
        // Add new flower
        arrangement.flowers.push({
            id: parseInt(flowerId),
            name: flowerName,
            price: flowerPrice,
            quantity: 1
        });
    }
    
    displayArrangement();
    calculateTotal();
}

// Load pre-designed bouquets
async function loadBouquets() {
    try {
        const response = await fetch('api.php?action=getBouquets');
        const bouquets = await response.json();
        
        const bouquetsList = document.getElementById('bouquetsList');
        bouquetsList.innerHTML = '';
        
        bouquets.forEach(bouquet => {
            const bouquetCard = document.createElement('div');
            bouquetCard.className = 'bouquet-card';

            // Determine image source: prefer bouquet.image (if provided), otherwise use mapping
            let bouquetImageSrc = './flowerimage/flowersrose.jfif';
            if (bouquet.image && bouquet.image.trim()) {
                bouquetImageSrc = (bouquet.image.startsWith('./') || bouquet.image.startsWith('/')) ? bouquet.image : './flowerimage/' + bouquet.image;
            } else {
                bouquetImageSrc = getBouquetImageSrc(bouquet.name);
            }

            bouquetCard.innerHTML = `
                <div class="bouquet-header">
                    <div class="bouquet-name">${bouquet.name}</div>
                    <div class="bouquet-description">${bouquet.description}</div>
                </div>
                <div class="bouquet-image-wrapper">
                    <img src="${bouquetImageSrc}" alt="${bouquet.name}" class="bouquet-image" onerror="this.src='./flowerimage/flowersrose.jfif'" />
                </div>
                <div class="bouquet-body">
                    <div class="bouquet-price">₱${parseFloat(bouquet.price).toFixed(2)}</div>
                    <button class="bouquet-button add-bouquet-btn" data-id="${bouquet.id}" data-name="${encodeURIComponent(bouquet.name)}" data-price="${bouquet.price}" data-image="${bouquetImageSrc}">Add to Cart</button>
                </div>
            `;

            bouquetsList.appendChild(bouquetCard);

            // Attach click handler safely (avoids inline onclick and escaping issues)
            const btn = bouquetCard.querySelector('.add-bouquet-btn');
            if (btn) {
                btn.addEventListener('click', function() {
                    const rawId = this.dataset.id;
                    const id = rawId === 'null' || rawId === '' ? null : parseInt(rawId);
                    const name = decodeURIComponent(this.dataset.name || '');
                    const price = parseFloat(this.dataset.price) || 0;
                    const image = this.dataset.image || '';
                    addBouquetToCart(id, name, price, image);
                });
            }
        });
        sanitizeCurrencySymbols();
    } catch (error) {
        console.error('Error loading bouquets:', error);
    }
}

// Update price when base is selected
function updatePrice() {
    const baseSelect = document.getElementById('base');
    const selectedOption = baseSelect.options[baseSelect.selectedIndex];
    
    if (selectedOption.value) {
        arrangement.base = {
            id: selectedOption.value,
            name: selectedOption.textContent.replace(/\s*\(₱[\d,.]+\)\s*$/, '').trim(),
            price: parseFloat(selectedOption.dataset.price)
        };
        arrangement.basePrice = arrangement.base.price;
        document.getElementById('basePrice').textContent = '₱' + arrangement.basePrice.toFixed(2);
    } else {
        arrangement.base = null;
        arrangement.basePrice = 0;
        document.getElementById('basePrice').textContent = '₱0.00';
    }
    
    calculateTotal();
}

// Update flower price display
function updateFlowerPrice() {
    const flowerSelect = document.getElementById('flower');
    const quantityInput = document.getElementById('quantity');
    const selectedOption = flowerSelect.options[flowerSelect.selectedIndex];
    
    if (selectedOption.value) {
        const price = parseFloat(selectedOption.dataset.price);
        const quantity = parseInt(quantityInput.value) || 1;
        const total = price * quantity;
        document.getElementById('flowerPrice').textContent = '₱' + total.toFixed(2);
    } else {
        document.getElementById('flowerPrice').textContent = '₱0.00';
    }
}

// Add flower to arrangement
function addFlower() {
    const flowerSelect = document.getElementById('flower');
    const quantityInput = document.getElementById('quantity');
    const selectedOption = flowerSelect.options[flowerSelect.selectedIndex];
    
    if (!selectedOption.value) {
        alert('Please select a flower');
        return;
    }
    
    if (!arrangement.base) {
        alert('Please select a base first');
        return;
    }
    
    const quantity = parseInt(quantityInput.value);
    const stock = parseInt(selectedOption.dataset.stock);
    
    if (quantity <= 0) {
        alert('Please enter a valid quantity');
        return;
    }
    
    if (quantity > stock) {
        alert(`Only ${stock} items available in stock`);
        return;
    }
    
    const flower = {
        id: selectedOption.value,
        name: selectedOption.text.split(' - ')[0],
        price: parseFloat(selectedOption.dataset.price),
        quantity: quantity
    };
    
    arrangement.flowers.push(flower);
    
    // Reset form
    flowerSelect.value = '';
    quantityInput.value = 1;
    updateFlowerPrice();
    
    // Update display
    displayArrangement();
    calculateTotal();
}

// Display arrangement items with visual representation
function displayArrangement() {
    const arrangementList = document.getElementById('arrangementList');
    const flowerDisplay = document.getElementById('flowerArrangement');
    const canvasPlaceholder = document.querySelector('.canvas-placeholder');
    
    if (!arrangementList || !flowerDisplay) {
        return;
    }

    if (arrangement.flowers.length === 0) {
        arrangementList.innerHTML = '<p class="empty-state-icon">No flowers added yet</p>';
        flowerDisplay.innerHTML = '';
        if (canvasPlaceholder) {
            canvasPlaceholder.style.display = 'block';
        }
        return;
    }
    
    if (canvasPlaceholder) {
        canvasPlaceholder.style.display = 'none';
    }
    
    arrangementList.innerHTML = '';
    flowerDisplay.innerHTML = '';
    
    arrangement.flowers.forEach((flower, index) => {
        const subtotal = flower.price * flower.quantity;
        const flowerImagePath = getFlowerImagePath(flower.name);
        
        // Add to list
        const item = document.createElement('div');
        item.className = 'item';
        item.innerHTML = `
            <div class="item-info">
                <div class="item-name" style="display: flex; align-items: center; gap: 0.4rem;">
                    <div style="width: 30px; height: 30px; border-radius: 3px; overflow: hidden; flex-shrink: 0; background: #f5f5f5;">
                        <img src="${flowerImagePath}" alt="${flower.name}" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    ${flower.name}
                </div>
                <div class="item-details">Qty: ${flower.quantity} × ₱${flower.price.toFixed(2)} = ₱${subtotal.toFixed(2)}</div>
            </div>
            <div class="item-controls">
                <button onclick="increaseFlower(${index})" class="btn btn-primary" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;">+</button>
                <button onclick="decreaseFlower(${index})" class="btn btn-danger" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;">-</button>
                <button onclick="removeFlower(${index})" class="btn btn-danger">Remove</button>
            </div>
        `;
        arrangementList.appendChild(item);
        
        // Add to visual display
        for (let i = 0; i < flower.quantity; i++) {
            const flowerVisual = document.createElement('div');
            flowerVisual.className = 'flower-visual';
            flowerVisual.style.overflow = 'hidden';
            flowerVisual.innerHTML = `<img src="${flowerImagePath}" alt="${flower.name}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 8px;">`;
            flowerDisplay.appendChild(flowerVisual);
        }
    });
}

// Increase flower quantity
function increaseFlower(index) {
    arrangement.flowers[index].quantity += 1;
    displayArrangement();
    calculateTotal();
}

// Decrease flower quantity
function decreaseFlower(index) {
    if (arrangement.flowers[index].quantity > 1) {
        arrangement.flowers[index].quantity -= 1;
    } else {
        removeFlower(index);
    }
    displayArrangement();
    calculateTotal();
}

// Remove flower from arrangement
function removeFlower(index) {
    arrangement.flowers.splice(index, 1);
    displayArrangement();
    calculateTotal();
}

// Clear all flowers
function clearArrangement() {
    if (confirm('Clear all flowers from your arrangement?')) {
        arrangement.flowers = [];
        displayArrangement();
        calculateTotal();
    }
}

// Calculate total price
function calculateTotal() {
    let flowerTotal = 0;
    arrangement.flowers.forEach(flower => {
        flowerTotal += flower.price * flower.quantity;
    });
    
    const total = arrangement.basePrice + flowerTotal;
    
    document.getElementById('totalBasePrice').textContent = '₱' + arrangement.basePrice.toFixed(2);
    document.getElementById('totalFlowersPrice').textContent = '₱' + flowerTotal.toFixed(2);
    document.getElementById('totalPrice').textContent = '₱' + total.toFixed(2);
}

function getSelectedArrangementStyle() {
    return document.querySelector('input[name="arrangementStyle"]:checked')?.value || 'flowers';
}

function showCustomValidation(message) {
    const validation = document.getElementById('customValidationMessage');
    if (!validation) return;
    validation.textContent = message;
    validation.style.display = 'block';
}

function clearCustomValidation() {
    const validation = document.getElementById('customValidationMessage');
    if (validation) {
        validation.textContent = '';
        validation.style.display = 'none';
    }
}

function handleStyleSelection() {
    const inspirationSelected = getSelectedArrangementStyle() === 'inspiration';
    const panel = document.getElementById('inspirationPanel');
    if (panel) panel.hidden = !inspirationSelected;
    clearCustomValidation();
}

function handleInspirationImage(input) {
    const file = input.files?.[0];
    const error = document.getElementById('uploadError');
    const preview = document.getElementById('uploadPreview');
    const previewImage = document.getElementById('inspirationPreview');
    const allowedTypes = ['image/jpeg', 'image/png'];

    if (!file) return;

    if (!allowedTypes.includes(file.type) || !/\.(jpe?g|png)$/i.test(file.name)) {
        input.value = '';
        error.textContent = 'Please choose a JPG, JPEG, or PNG image.';
        error.style.display = 'block';
        preview.style.display = 'none';
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        input.value = '';
        error.textContent = 'The inspiration image must be 5 MB or smaller.';
        error.style.display = 'block';
        preview.style.display = 'none';
        return;
    }

    error.textContent = '';
    error.style.display = 'none';
    previewImage.src = URL.createObjectURL(file);
    preview.style.display = 'flex';
    clearCustomValidation();
}

function removeInspirationImage() {
    const input = document.getElementById('inspirationImage');
    const preview = document.getElementById('uploadPreview');
    const previewImage = document.getElementById('inspirationPreview');
    if (input) input.value = '';
    if (previewImage) previewImage.removeAttribute('src');
    if (preview) preview.style.display = 'none';
}

async function uploadInspirationImage() {
    const input = document.getElementById('inspirationImage');
    const file = input?.files?.[0];
    if (!file) return null;

    const formData = new FormData();
    formData.append('inspirationImage', file);
    const response = await fetch('api/upload_inspiration.php', {
        method: 'POST',
        body: formData
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
        throw new Error(result.message || 'The inspiration image could not be uploaded.');
    }
    return result.path;
}

// Add custom arrangement to cart
async function addCustomToCart() {
    clearCustomValidation();

    if (!arrangement.base) {
        showCustomValidation('Please select a base before proceeding.');
        return;
    }

    const style = getSelectedArrangementStyle();
    const imageInput = document.getElementById('inspirationImage');
    const waiver = document.getElementById('waiverAgreement');
    if (style === 'flowers' && arrangement.flowers.length === 0) {
        showCustomValidation('Please select at least one flower for the stylist’s choice option.');
        return;
    }

    if (style === 'inspiration' && !imageInput?.files?.[0]) {
        showCustomValidation('Please upload an inspiration image before proceeding.');
        return;
    }

    if (style === 'inspiration' && !waiver?.checked) {
        showCustomValidation('Please read and agree to the customization terms before proceeding.');
        waiver?.focus();
        return;
    }

    let inspirationImage = null;
    if (style === 'inspiration') {
        try {
            inspirationImage = await uploadInspirationImage();
        } catch (error) {
            showCustomValidation(error.message);
            return;
        }
    }

    const notes = document.getElementById('arrangementNotes')?.value || '';
    const flowerTotal = arrangement.flowers.reduce((total, flower) => total + (flower.price * flower.quantity), 0);
    
    // Get cart from localStorage
    let cart = JSON.parse(localStorage.getItem(getCartStorageKey())) || [];
    
    // Add custom arrangement to cart
    const cartItem = {
        id: 'custom_' + Date.now(),
        type: 'custom',
        base: arrangement.base,
        style: style,
        styleLabel: style === 'flowers' ? 'Select Your Flowers (Stylist’s Choice)' : 'Upload an Inspiration Photo (Custom Peg)',
        flowers: arrangement.flowers,
        inspirationImage: inspirationImage,
        waiverAgreed: style === 'inspiration' ? true : false,
        notes: notes,
        total: arrangement.basePrice + flowerTotal
    };
    
    cart.push(cartItem);
    
    // Save to localStorage
    localStorage.setItem(getCartStorageKey(), JSON.stringify(cart));
    
    // Reset arrangement data
    arrangement = {
        base: null,
        basePrice: 0,
        flowers: []
    };
    const baseSelect = document.getElementById('base');
    if (baseSelect) {
        baseSelect.selectedIndex = 0;
    }

    document.querySelector('input[name="arrangementStyle"][value="flowers"]')?.click();
    removeInspirationImage();
    const notesInput = document.getElementById('arrangementNotes');
    if (notesInput) notesInput.value = '';
    const waiverInput = document.getElementById('waiverAgreement');
    if (waiverInput) waiverInput.checked = false;

    const arrangementList = document.getElementById('arrangementList');
    if (arrangementList) {
        arrangementList.innerHTML = '';
    }

    const flowerArrangement = document.getElementById('flowerArrangement');
    if (flowerArrangement) {
        flowerArrangement.innerHTML = '';
    }

    const canvasPlaceholder = document.querySelector('.canvas-placeholder');
    if (canvasPlaceholder) {
        canvasPlaceholder.style.display = 'block';
    }

    updatePrice();
    displayArrangement();
    updateCartCount();
    showCartMessage('Your custom arrangement was added to the cart.');
}

// Add pre-designed bouquet to cart
function addBouquetToCart(bouquetId, bouquetName, price, image) {
    let cart = JSON.parse(localStorage.getItem(getCartStorageKey())) || [];

    // Prefer explicit image parameter (passed from button). Fallback to DOM lookup.
    let imageSrc = image || '';
    if (!imageSrc) {
        try {
            const selector = bouquetId === null ? '.add-bouquet-btn[data-id="null"]' : `.add-bouquet-btn[data-id="${bouquetId}"]`;
            const card = document.querySelector(selector);
            if (card) {
                const wrapper = card.closest('.bouquet-card').querySelector('.bouquet-image');
                if (wrapper && wrapper.src) imageSrc = wrapper.src;
            }
        } catch (e) {
            console.warn('Could not determine bouquet image for cart item', e);
        }
    }

    const cartItem = {
        id: 'bouquet_' + (bouquetId === null ? 'new' : bouquetId) + '_' + Date.now(),
        type: 'bouquet',
        bouquetId: bouquetId,
        bouquetName: bouquetName,
        price: price,
        quantity: 1,
        image: imageSrc
    };
    
    cart.push(cartItem);
    localStorage.setItem(getCartStorageKey(), JSON.stringify(cart));
    
    showCartMessage('Successfully added your bouquet to the cart.');
    updateCartCount();
}

// Update cart count
function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem(getCartStorageKey())) || [];
    const countBadge = document.getElementById('cart-count');
    if (countBadge) {
        countBadge.textContent = cart.length;
    }
}

// Update order count
function updateOrderCount() {
    // Assuming we have a way to get order count, for now set to 0 or fetch from server
    // Since we don't have a global order count, we'll set it to 0 for now
    // In a real app, this would be fetched via AJAX
    const countBadge = document.getElementById('order-count');
    if (countBadge) {
        // For now, just set to 0; in production, fetch from API
        countBadge.textContent = '0'; // Placeholder
    }
}

function showCartMessage(message, type = 'success') {
    let alertContainer = document.getElementById('cartAlert');
    if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.id = 'cartAlert';
        alertContainer.className = 'alert-message success';
        const target = document.querySelector('.custom-arrangement') || document.body;
        target.insertBefore(alertContainer, target.firstChild);
    }
    alertContainer.textContent = message;
    alertContainer.className = `alert-message ${type}`;
    alertContainer.style.display = 'block';
    setTimeout(() => {
        alertContainer.style.display = 'none';
    }, 3500);
}

// Suggest flowers based on occasion
function suggestFlowers() {
    const occasion = document.getElementById('occasion').value;
    const suggestionBox = document.getElementById('suggestionBox');
    const suggestionText = document.getElementById('suggestionText');
    
    const suggestions = {
        birthday: '🎂 For birthdays, we recommend bright colors like Tulips, Sunflowers, and Daisies!',
        anniversary: '💕 For anniversaries, romantic red Roses with Lilies make a perfect choice!',
        funeral: '🤍 For funerals, we suggest white and soft-colored flowers like Lilies and Daisies.'
    };
    
    if (occasion) {
        suggestionText.textContent = suggestions[occasion];
        suggestionBox.style.display = 'block';
    } else {
        suggestionBox.style.display = 'none';
    }
}

// Load arrangement from localStorage
function loadArrangement() {
    setupDropZone();
}

// Display cart items
function displayCart() {
    const cart = JSON.parse(localStorage.getItem(getCartStorageKey())) || [];
    const cartItemsDiv = document.getElementById('cartItems');
    
    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '<div class="empty-state"><div class="empty-state-icon">�️</div><p>Your cart is empty</p></div>';
        document.getElementById('orderSummary').style.display = 'none';
        return;
    }
    
    document.getElementById('orderSummary').style.display = 'block';
    cartItemsDiv.innerHTML = '';
    
    let totalPrice = 0;
    
    cart.forEach((item, index) => {
        let itemHTML = '';
        let itemPrice = 0;
        
        if (item.type === 'custom') {
            const baseName = item.base?.name || (item.base?.id ? `Base #${item.base.id}` : (item.basePrice ? 'Base' : 'Unknown Base'));
            const basePrice = parseFloat(item.base?.price ?? item.basePrice ?? 0) || 0;
            const flowersHtml = (item.flowers || []).map(f => {
                const flowerPrice = parseFloat(f.price || 0) || 0;
                const quantity = parseInt(f.quantity || 0, 10) || 0;
                return `<li>${escapeCartText(f.name)} × ${quantity} (₱${(flowerPrice * quantity).toFixed(2)})</li>`;
            }).join('');
            const flowersTotal = (item.flowers || []).reduce((total, flower) => {
                return total + ((parseFloat(flower.price || 0) || 0) * (parseInt(flower.quantity || 0, 10) || 0));
            }, 0);
            itemPrice = basePrice + flowersTotal;
            const styleLabel = item.styleLabel || (item.style === 'inspiration' ? 'Upload an Inspiration Photo (Custom Peg)' : 'Select Your Flowers (Stylist’s Choice)');
            const imageHtml = item.inspirationImage ? `<p><strong>Inspiration image:</strong><br><img src="${escapeCartAttribute(item.inspirationImage)}" alt="Uploaded inspiration" style="max-width:180px;max-height:180px;object-fit:cover;border-radius:6px;margin-top:0.35rem;"></p>` : '';
            const notesHtml = item.notes ? `<p><strong>Additional notes:</strong><br>${escapeCartText(item.notes).replace(/\n/g, '<br>')}</p>` : '';
            const waiverHtml = item.style === 'inspiration' ? `<p><strong>Customization waiver:</strong> ${item.waiverAgreed ? 'Agreed' : 'Not agreed'}</p>` : '';
            itemHTML = `
                <div class="cart-item">
                    <div>
                        <h4>Custom Arrangement</h4>
                        <p>Base: ${baseName} (₱${basePrice.toFixed(2)})</p>
                        <p><strong>Style Selection:</strong> ${escapeCartText(styleLabel)}</p>
                        <p><strong>Flowers total:</strong> ₱${flowersTotal.toFixed(2)}</p>
                        <ul style="margin-left: 1rem; margin-top: 0.5rem;">
                            ${flowersHtml}
                        </ul>
                        ${imageHtml}
                        ${waiverHtml}
                        ${notesHtml}
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: bold; color: #667eea; margin-bottom: 0.5rem;">₱${itemPrice.toFixed(2)}</div>
                        <button onclick="removeFromCart(${index})" class="btn btn-danger btn-sm">Remove</button>
                    </div>
                </div>
            `;
        } else if (item.type === 'bouquet') {
            itemPrice = parseFloat(item.price || 0) || 0;
            const imageHtml = item.image ? `<img src="${item.image}" style="width:72px;height:72px;object-fit:cover;border-radius:6px;margin-right:0.5rem;">` : '';
            itemHTML = `
                <div class="cart-item" style="display:flex;align-items:center;gap:0.75rem;">
                    ${imageHtml}
                    <div style="flex:1;">
                        <h4 style="margin:0 0 0.25rem 0;">${item.bouquetName}</h4>
                        <p style="margin:0;font-size:0.95rem;">Quantity: ${item.quantity}</p>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: bold; color: #667eea; margin-bottom: 0.5rem;">₱${itemPrice.toFixed(2)}</div>
                        <button onclick="removeFromCart(${index})" class="btn btn-danger btn-sm">Remove</button>
                    </div>
                </div>
            `;
        }
        
        totalPrice += itemPrice;
        cartItemsDiv.innerHTML += itemHTML;
    });
    
    // Update order summary
    const subtotalElement = document.getElementById('cartSubtotal');
    const totalElement = document.getElementById('cartTotal');
    if (subtotalElement) {
        subtotalElement.textContent = '₱' + totalPrice.toFixed(2);
    }
    if (totalElement) {
        totalElement.textContent = '₱' + totalPrice.toFixed(2);
    }
    document.getElementById('checkoutTotal').value = totalPrice.toFixed(2);
    sanitizeCurrencySymbols();
}

function escapeCartText(value) {
    return String(value ?? '').replace(/[&<>'"]/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[character]));
}

function escapeCartAttribute(value) {
    return escapeCartText(value).replace(/javascript:/gi, '');
}

// Remove item from cart
function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem(getCartStorageKey())) || [];
    cart.splice(index, 1);
    localStorage.setItem(getCartStorageKey(), JSON.stringify(cart));
    displayCart();
    updateCartCount();
}

// Clear entire cart
function clearCart() {
    if (confirm('Are you sure you want to clear your cart?')) {
        localStorage.removeItem(getCartStorageKey());
        displayCart();
        updateCartCount();
    }
}

// Checkout
async function checkout() {
    const form = document.getElementById('checkoutForm');
    const name = document.getElementById('customerName').value.trim();
    const email = document.getElementById('customerEmail').value.trim();
    const phone = document.getElementById('customerPhone').value.trim();
    const address = document.getElementById('customerAddress').value.trim();
    const orderType = document.getElementById('orderType').value;
    
    if (!name || !email || !phone || !address) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Email validation
    if (!email.includes('@')) {
        alert('Please enter a valid email');
        return;
    }
    
    // Phone validation
    if (phone.length < 10) {
        alert('Please enter a valid phone number');
        return;
    }
    
    const cart = JSON.parse(localStorage.getItem(getCartStorageKey())) || [];
    
    if (cart.length === 0) {
        alert('Your cart is empty');
        return;
    }
    
    try {
        const response = await fetch('api/orders.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                customerName: name,
                customerEmail: email,
                customerPhone: phone,
                customerAddress: address,
                orderType: orderType,
                cart: cart
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Order placed successfully! Order ID: ' + result.orderId);
            localStorage.removeItem(getCartStorageKey());
            displayCart();
            updateCartCount();
            form.reset();
        } else {
            console.error('Order failed response:', result);
            alert('Error placing order: ' + (result.message || 'Please try again.'));
        }
    } catch (error) {
        console.error('Error placing order:', error);
        alert('Error placing order. Please try again.');
    }
}
