<?php
$conn = new mysqli('localhost', 'root', '');
$conn->query('DROP DATABASE IF EXISTS flower_shop');
$conn->query('CREATE DATABASE flower_shop');
echo 'Database recreated successfully';
$conn->close();
?>