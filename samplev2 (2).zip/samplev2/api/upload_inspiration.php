<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please log in before uploading an inspiration image.']);
    exit;
}

if (!isset($_FILES['inspirationImage']) || $_FILES['inspirationImage']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please choose a valid inspiration image.']);
    exit;
}

$file = $_FILES['inspirationImage'];
$maxSize = 5 * 1024 * 1024;
$allowedMimeTypes = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png'
];

if ($file['size'] > $maxSize) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'The inspiration image must be 5 MB or smaller.']);
    exit;
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($file['tmp_name']);
if (!isset($allowedMimeTypes[$mimeType])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Only JPG, JPEG, and PNG images are supported.']);
    exit;
}

$uploadDirectory = __DIR__ . '/../flowerimage/custom_uploads';
if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The image upload directory is unavailable.']);
    exit;
}

$fileName = 'inspiration_' . intval($_SESSION['user_id']) . '_' . bin2hex(random_bytes(12)) . '.' . $allowedMimeTypes[$mimeType];
$destination = $uploadDirectory . DIRECTORY_SEPARATOR . $fileName;
if (!move_uploaded_file($file['tmp_name'], $destination)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The inspiration image could not be saved.']);
    exit;
}

echo json_encode([
    'success' => true,
    'path' => 'flowerimage/custom_uploads/' . $fileName
]);
