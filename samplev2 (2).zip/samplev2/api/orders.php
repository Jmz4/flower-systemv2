<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($method === 'GET') {
    $action = $_GET['action'] ?? '';

    if ($action === 'getOrderDetails') {
        $orderId = intval($_GET['orderId'] ?? 0);

        if (!$orderId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Order ID is required']);
            exit;
        }

        // Fetch order details
        $sql = "SELECT id, customer_name, customer_email, customer_phone, customer_address, order_type, total_price, status, created_at FROM orders WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $orderResult = $stmt->get_result();

        if ($orderResult->num_rows === 0) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Order not found']);
            exit;
        }

        $order = $orderResult->fetch_assoc();

        // Fetch order items
        $itemsSql = "SELECT oi.flower_id, oi.bouquet_id, oi.base_id, oi.quantity, oi.unit_price, oi.subtotal,
                    COALESCE(f.name, b.name, bs.name, 'Item') as name,
                    bs.name AS base_name,
                            oi.custom_style, oi.custom_notes, oi.inspiration_image, oi.waiver_agreed
                     FROM order_items oi
                     LEFT JOIN flowers f ON oi.flower_id = f.id
                     LEFT JOIN bouquets b ON oi.bouquet_id = b.id
                LEFT JOIN bases bs ON oi.base_id = bs.id
                     WHERE oi.order_id = ?";
        $itemsStmt = $conn->prepare($itemsSql);
        $itemsStmt->bind_param('i', $orderId);
        $itemsStmt->execute();
        $itemsResult = $itemsStmt->get_result();

        $items = [];
        while ($item = $itemsResult->fetch_assoc()) {
            $items[] = $item;
        }

        echo json_encode([
            'success' => true,
            'order' => $order,
            'items' => $items
        ]);
        exit;
    }

    // Default GET - fetch all orders
    $orders = [];
    $sql = "SELECT id, customer_name, customer_email, customer_phone, total_price, status, created_at FROM orders ORDER BY created_at DESC";
    $result = $conn->query($sql);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }

    echo json_encode(['success' => true, 'orders' => $orders]);
    exit;
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    $customerName = trim($input['customerName'] ?? '');
    $customerEmail = trim($input['customerEmail'] ?? '');
    $customerPhone = trim($input['customerPhone'] ?? '');
    $customerAddress = trim($input['customerAddress'] ?? '');
    $orderType = $input['orderType'] ?? 'delivery';
    $cart = $input['cart'] ?? [];

    if (!$customerName || !$customerEmail || !$customerPhone || !$customerAddress) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Please complete all customer details.']);
        exit;
    }

    if (!filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
        exit;
    }

    if (empty($cart)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Your cart is empty.']);
        exit;
    }

    $conn->begin_transaction();

    try {
        $totalPrice = 0;
        foreach ($cart as $cartItem) {
            if (isset($cartItem['total'])) {
                $totalPrice += floatval($cartItem['total']);
            } elseif (isset($cartItem['price']) && isset($cartItem['quantity'])) {
                $totalPrice += floatval($cartItem['price']) * intval($cartItem['quantity']);
            }
        }

        $userId = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;

        if ($userId) {
                $sql = "INSERT INTO orders (user_id, customer_name, customer_email, customer_phone, customer_address, order_type, total_price, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('isssssd', $userId, $customerName, $customerEmail, $customerPhone, $customerAddress, $orderType, $totalPrice);
        } else {
                $sql = "INSERT INTO orders (customer_name, customer_email, customer_phone, customer_address, order_type, total_price, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('sssssd', $customerName, $customerEmail, $customerPhone, $customerAddress, $orderType, $totalPrice);
        }
        $stmt->execute();
        $orderId = $stmt->insert_id;

        foreach ($cart as $cartItem) {
            if (!isset($cartItem['type'])) {
                continue;
            }

            if ($cartItem['type'] === 'custom') {
                $style = ($cartItem['style'] ?? '') === 'inspiration' ? 'inspiration' : 'flowers';
                $notes = substr((string) ($cartItem['notes'] ?? ''), 0, 10000);
                $inspirationImage = $style === 'inspiration' ? (string) ($cartItem['inspirationImage'] ?? '') : '';
                $waiverAgreed = $style === 'inspiration' && !empty($cartItem['waiverAgreed']) ? 1 : 0;

                if ($style === 'inspiration' && (!$inspirationImage || !$waiverAgreed)) {
                    throw new Exception('The inspiration image and customization agreement are required.');
                }
                if ($inspirationImage && !preg_match('#^flowerimage/custom_uploads/[A-Za-z0-9_-]+\.(?:jpg|jpeg|png)$#i', $inspirationImage)) {
                    throw new Exception('The inspiration image reference is invalid.');
                }

                if (!empty($cartItem['base']['id'])) {
                    $baseId = intval($cartItem['base']['id']);
                    $basePrice = floatval($cartItem['base']['price']);
                        $sql = "INSERT INTO order_items (order_id, item_type, base_id, quantity, unit_price, subtotal, custom_style, custom_notes, inspiration_image, waiver_agreed)
                            VALUES (?, 'flower', ?, 1, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                        $stmt->bind_param('iiddsssi', $orderId, $baseId, $basePrice, $basePrice, $style, $notes, $inspirationImage, $waiverAgreed);
                    $stmt->execute();
                }

                if (!empty($cartItem['flowers']) && is_array($cartItem['flowers'])) {
                    foreach ($cartItem['flowers'] as $flower) {
                        $flowerId = intval($flower['id'] ?? 0);
                        $quantity = intval($flower['quantity'] ?? 1);
                        $unitPrice = floatval($flower['price'] ?? 0);
                        $subtotal = $quantity * $unitPrice;

                        $sql = "INSERT INTO order_items (order_id, item_type, flower_id, quantity, unit_price, subtotal)
                                VALUES (?, 'flower', ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param('iiidd', $orderId, $flowerId, $quantity, $unitPrice, $subtotal);
                        $stmt->execute();

                        if ($flowerId > 0) {
                            $updateStock = $conn->prepare("UPDATE flowers SET stock = stock - ? WHERE id = ? AND stock >= ?");
                            $updateStock->bind_param('iii', $quantity, $flowerId, $quantity);
                            $updateStock->execute();
                        }
                    }
                }
            }

            if ($cartItem['type'] === 'bouquet') {
                $rawBouquetId = $cartItem['bouquetId'] ?? null;
                $quantity = intval($cartItem['quantity'] ?? 1);
                $unitPrice = floatval($cartItem['price'] ?? 0);
                $subtotal = $unitPrice * $quantity;

                // Validate bouquet ID: if numeric and exists in DB, reference it; otherwise insert with NULL to avoid FK errors
                $bouquetId = null;
                if (is_numeric($rawBouquetId) && intval($rawBouquetId) > 0) {
                    $checkStmt = $conn->prepare('SELECT id FROM bouquets WHERE id = ? LIMIT 1');
                    $checkId = intval($rawBouquetId);
                    $checkStmt->bind_param('i', $checkId);
                    $checkStmt->execute();
                    $checkRes = $checkStmt->get_result();
                    if ($checkRes && $checkRes->num_rows > 0) {
                        $bouquetId = $checkId;
                    }
                }

                if ($bouquetId === null) {
                    // Insert order item without bouquet reference (uploaded-only bouquet)
                    $sql = "INSERT INTO order_items (order_id, item_type, bouquet_id, quantity, unit_price, subtotal) VALUES (?, 'bouquet', NULL, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param('iidd', $orderId, $quantity, $unitPrice, $subtotal);
                    $stmt->execute();
                    // No stock deduction since composition isn't stored in DB
                } else {
                    // Insert with bouquet id and deduct stock
                    $sql = "INSERT INTO order_items (order_id, item_type, bouquet_id, quantity, unit_price, subtotal) VALUES (?, 'bouquet', ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param('iiidd', $orderId, $bouquetId, $quantity, $unitPrice, $subtotal);
                    $stmt->execute();

                    $sql = "SELECT flower_id, quantity FROM bouquet_items WHERE bouquet_id = ?";
                    $stmtItems = $conn->prepare($sql);
                    $stmtItems->bind_param('i', $bouquetId);
                    $stmtItems->execute();
                    $itemsResult = $stmtItems->get_result();
                    while ($item = $itemsResult->fetch_assoc()) {
                        $flowerQuantity = intval($item['quantity']) * $quantity;
                        $flowerID = intval($item['flower_id']);
                        $updateStock = $conn->prepare("UPDATE flowers SET stock = stock - ? WHERE id = ? AND stock >= ?");
                        $updateStock->bind_param('iii', $flowerQuantity, $flowerID, $flowerQuantity);
                        $updateStock->execute();
                    }
                }
            }
        }

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Order placed successfully.', 'orderId' => $orderId]);
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to save order: ' . $e->getMessage()]);
    }

    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
