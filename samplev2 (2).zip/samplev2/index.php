<?php
require_once 'config.php';

$isLoggedIn = isset($_SESSION['user_id']);

// Redirect non-logged-in users to welcome page
if (!$isLoggedIn) {
    header('Location: welcome.php');
    exit;
}

// Logged-in users go to choices page
header('Location: choices.php');
exit;
?>
