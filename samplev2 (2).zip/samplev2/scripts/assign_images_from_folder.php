<?php
/**
 * assign_images_from_folder.php
 *
 * Attempt to auto-assign image filenames from the flowerimage/ folder
 * to bouquets in the database by doing a best-effort filename match.
 *
 * Usage: run from the project root with PHP CLI or via browser.
 */
require_once __DIR__ . '/../config.php';

$dir = __DIR__ . '/../flowerimage/';
$files = array_diff(scandir($dir), array('.', '..'));

// Normalize filenames to a simple searchable key
$normalizedFiles = [];
foreach ($files as $f) {
    $key = strtolower(preg_replace('/[^a-z0-9]+/', ' ', pathinfo($f, PATHINFO_FILENAME)));
    $normalizedFiles[$f] = $key;
}

// Fetch bouquets
$sql = "SELECT id, name FROM bouquets";
$result = $conn->query($sql);
if (!$result) {
    echo "Error fetching bouquets: " . $conn->error;
    exit;
}

$updates = [];
while ($row = $result->fetch_assoc()) {
    $bId = $row['id'];
    $bName = strtolower(preg_replace('/[^a-z0-9]+/', ' ', $row['name']));

    $bestMatch = null;
    $bestScore = 0;

    foreach ($normalizedFiles as $filename => $norm) {
        // score based on number of matching words
        $wordsB = array_filter(explode(' ', $bName));
        $score = 0;
        foreach ($wordsB as $w) {
            if (strlen($w) < 3) continue;
            if (strpos($norm, $w) !== false) $score++;
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $bestMatch = $filename;
        }
    }

    if ($bestMatch && $bestScore > 0) {
        // Update bouquet record
        $imageName = $bestMatch; // store filename as-is
        $stmt = $conn->prepare("UPDATE bouquets SET image = ? WHERE id = ?");
        $stmt->bind_param('si', $imageName, $bId);
        if ($stmt->execute()) {
            $updates[] = [
                'id' => $bId,
                'name' => $row['name'],
                'image' => $imageName,
                'score' => $bestScore
            ];
        }
    }
}

header('Content-Type: application/json');
echo json_encode(['updated' => $updates], JSON_PRETTY_PRINT);
