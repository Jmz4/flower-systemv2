<?php
/**
 * add_bouquets_from_images.php
 *
 * Adds bouquets to the `bouquets` table for a predefined mapping of
 * image filenames (in flowerimage/) to friendly bouquet names.
 * Skips insertion if a bouquet with the same image or name already exists.
 *
 * Run: php scripts/add_bouquets_from_images.php
 */
require_once __DIR__ . '/../config.php';

// Mapping: filename => friendly name
$mapping = [
    'lcflower1.jpg' => 'Sunset Bliss',
    'lcflower2.jpg' => 'Golden Embrace',
    'lcflower3.jpg' => 'Rosy Whisper',
    'lcflower4.jpg' => 'Pastel Dream',
    'lcflower5.jpg' => 'Sweet Serenade',
    'lcflower6.jpg' => 'Pink Promise',
    'lcflower7.jpg' => 'Lavender Luxe',
    'lcflower8.jpg' => 'Sunny Delight',
    'lcflower9.jpg' => 'Honey Glow',
    'lcflower10.jpg' => 'Crimson Charm',
    'lcflower11.jpg' => 'Purple Haze',
    'lcflower12.jpg' => 'The Beautiful You',
    'lcflower13.jpg' => 'Radiant Bloom'
];

$defaultPrice = 45.00;
$defaultBaseId = 1; // assume base 1 exists (Bouquet)

$results = ['inserted' => [], 'skipped' => [], 'errors' => []];

foreach ($mapping as $filename => $friendlyName) {
    // Check file exists
    $filePath = __DIR__ . '/../flowerimage/' . $filename;
    if (!file_exists($filePath)) {
        $results['skipped'][] = ['filename' => $filename, 'reason' => 'file not found'];
        continue;
    }

    // Check by image
    $stmt = $conn->prepare('SELECT id FROM bouquets WHERE image = ? OR name = ? LIMIT 1');
    $stmt->bind_param('ss', $filename, $friendlyName);
    if (!$stmt->execute()) {
        $results['errors'][] = ['filename' => $filename, 'error' => $conn->error];
        continue;
    }
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $results['skipped'][] = ['filename' => $filename, 'reason' => 'already exists', 'bouquet_id' => $row['id']];
        continue;
    }

    // Insert bouquet
    $description = 'Pre-designed bouquet: ' . $friendlyName;
    $insert = $conn->prepare('INSERT INTO bouquets (name, description, price, base_id, image) VALUES (?, ?, ?, ?, ?)');
    $insert->bind_param('ssdiss', $friendlyName, $description, $defaultPrice, $defaultBaseId, $filename);
    if ($insert->execute()) {
        $results['inserted'][] = ['filename' => $filename, 'id' => $insert->insert_id, 'name' => $friendlyName];
    } else {
        $results['errors'][] = ['filename' => $filename, 'error' => $conn->error];
    }
}

header('Content-Type: application/json');
echo json_encode($results, JSON_PRETTY_PRINT);
