<?php
require_once 'config.php';

$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');
$orderCount = 0;
$isLoggedIn = isset($_SESSION['user_id']);

if ($isLoggedIn) {
    $userId = intval($_SESSION['user_id']);
    $orderCountSql = "SELECT COUNT(*) AS count FROM orders WHERE user_id = ?";
    $orderCountStmt = $conn->prepare($orderCountSql);
    $orderCountStmt->bind_param('i', $userId);
    $orderCountStmt->execute();
    $orderCountResult = $orderCountStmt->get_result();
    $orderCountRow = $orderCountResult->fetch_assoc();
    $orderCount = $orderCountRow['count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About L&C Flowershop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="reviews.php">Reviews</a></li>
                    <li><a href="about.php">About</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="myorders.php">My Orders <span id="order-count"><?php echo $orderCount; ?></span></a></li>
                    <?php endif; ?>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if ($isLoggedIn): ?>
                        <?php if (isAdminOrStaff()): ?>
                            <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                        <?php endif; ?>
                        <li><a href="logout.php">Logout</a></li>
                        <li class="nav-user">Welcome, <?php echo $username; ?></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <section class="about-page">
            <div class="about-hero">
                <div>
                    <h1>Why Choose L&C Flowershop?</h1>
                    <p>At L&C Flowershop, every bouquet is crafted with care, creativity, and a passion for making your special moments bloom. We combine premium flowers, thoughtful design, and dependable service so every order arrives looking beautiful and feeling personal.</p>
                </div>
                <div>
                    <img src="./flowerimage/about pic.jpg" alt="About L&C Flowershop" class="about-hero-image" onerror="this.src='./flowerimage/Happy Birthday Bouquet.jfif'">
                </div>
            </div>

            <div class="about-grid">
                <div class="about-card">
                    <h3>Fresh and Beautiful Blooms</h3>
                    <p>We source only the freshest flowers so every arrangement looks vibrant and stays fresh longer. From classic roses to seasonal favorites, our selection is curated for quality and beauty.</p>
                </div>
                <div class="about-card">
                    <h3>Personalized Design</h3>
                    <p>Every order is tailored to your occasion. Whether it's a birthday surprise, anniversary celebration, or sympathy bouquet, our designers create arrangements that match your vision.</p>
                </div>
                <div class="about-card">
                    <h3>Trusted Local Service</h3>
                    <p>With reliable delivery, easy ordering, and friendly support, L&C Flowershop is proud to be a trusted choice for customers who want thoughtful floral gifts and memorable bouquets.</p>
                </div>
            </div>

            <div class="about-footer">
                <h3>About L&C Flowershop</h3>
                <p>L&C Flowershop began with a love for flowers and a desire to spread joy through every arrangement. Our team believes in making each order feel
special, from the moment you choose your bouquet to the moment it arrives. We take pride in being your trusted partner for beautiful flowers and
memorable moments.
                </p>
            </div>
        </section>
    </main>

    <footer>
        <p></p>
    </footer>
</body>
</html>
