<?php
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$message = '';
$messageType = '';

if (isset($_GET['registered']) && $_GET['registered'] == '1') {
    $message = 'Registration successful. Please log in.';
    $messageType = 'success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $message = 'Please fill in all fields.';
        $messageType = 'error';
    } else {
        $sql = "SELECT id, password, is_admin FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        $user = null;
        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();
        }

        if ($user !== null) {
            $storedPassword = $user['password'];
            $passwordOk = password_verify($password, $storedPassword) || ($storedPassword === $password);

            if ($passwordOk) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $username;
                $_SESSION['is_admin'] = (int) $user['is_admin'];

                $isAdmin = (int) $user['is_admin'] === 1;
                $role = $isAdmin ? 'admin' : (($username === 'staff') ? 'staff' : 'customer');
                $_SESSION['role'] = $role;

                if ($role === 'admin') {
                    header('Location: admin.php');
                    exit;
                } elseif ($role === 'staff') {
                    header('Location: staff.php');
                    exit;
                }

                header('Location: index.php');
                exit;
            }

            $message = 'Invalid username or password.';
            $messageType = 'error';
        } elseif ($username === 'staff' && $password === 'staff123') {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $email = 'staff@flowershop.com';
            $insertSql = "INSERT INTO users (username, password, email, is_admin) VALUES (?, ?, ?, 0)";
            $insertStmt = $conn->prepare($insertSql);
            $insertStmt->bind_param("sss", $username, $hashedPassword, $email);
            if ($insertStmt->execute()) {
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['username'] = $username;
                $_SESSION['is_admin'] = 0;
                $_SESSION['role'] = 'staff';
                header('Location: staff.php');
                exit;
            }

            $message = 'Invalid username or password.';
            $messageType = 'error';
        } else {
            $message = 'Invalid username or password.';
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">L&C Flowershop</div>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="cart.php">🛒 Cart</a></li>
                    <li><a href="register.php">Register</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <div class="login-container">
            <h1>Login</h1>

            <?php if (!empty($message)): ?>
                <div class="<?php echo $messageType === 'error' ? 'error-message' : 'success-message'; ?>"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <form method="POST" action="login.php">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-full" style="margin-top: 1rem; font-size: 1.1rem;">Login</button>
            </form>

            <div style="margin-top: 1rem; text-align: center; padding-top: 1rem; border-top: 1px solid #ddd;">
                <p>Don't have an account? <a href="register.php">Register here</a>.</p>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Flower Shop. All rights reserved. | Contact: info@flowershop.com</p>
    </footer>
</body>
</html>
