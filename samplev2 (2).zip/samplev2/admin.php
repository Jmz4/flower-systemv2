<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">L&C Flowershop - Admin</div>
                <ul class="nav-links">
                    <li><a href="index.php">Store</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <?php
        require_once 'config.php';

        // Check if user is logged in and is admin
        if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
            header('Location: login.php');
            exit;
        }

        $page = $_GET['page'] ?? 'orders';

        // Handle actions
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['action'])) {
                $action = $_POST['action'];

                if ($action === 'updateOrderStatus') {
                    $orderId = intval($_POST['orderId'] ?? 0);
                    $status = $_POST['status'] ?? '';
                    if (!in_array($status, ORDER_STATUSES, true)) {
                        echo '<div class="error-message">Invalid order status.</div>';
                    } else {
                        $currentStmt = $conn->prepare("SELECT status FROM orders WHERE id = ?");
                        $currentStmt->bind_param("i", $orderId);
                        $currentStmt->execute();
                        $currentOrder = $currentStmt->get_result()->fetch_assoc();

                        if (!$currentOrder) {
                            echo '<div class="error-message">Order not found.</div>';
                        } elseif ($currentOrder['status'] === 'Cancelled') {
                            echo '<div class="error-message">Cancelled orders are permanent and cannot be changed.</div>';
                        } else {
                            $sql = "UPDATE orders SET status = ? WHERE id = ? AND status <> 'Cancelled'";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("si", $status, $orderId);
                        }
                    }
                    if (isset($stmt) && $stmt->execute()) {
                        logAction('update_order_status', "Updated order #$orderId to status: $status");
                        echo '<div class="success-message">Order status updated successfully</div>';
                    } elseif (isset($stmt)) {
                        echo '<div class="error-message">Error updating order status</div>';
                    }
                } else if ($action === 'addProduct') {
                    $name = $_POST['name'];
                    $price = $_POST['price'];
                    $stock = $_POST['stock'];
                    $sql = "INSERT INTO flowers (name, price, stock) VALUES (?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sdi", $name, $price, $stock);
                    if ($stmt->execute()) {
                        $productId = $conn->insert_id;
                        logAction('add_product', "Added product: $name (ID: $productId) - Price: ₱$price, Stock: $stock");
                        echo '<div class="success-message">Product added successfully</div>';
                    } else {
                        echo '<div class="error-message">Error adding product</div>';
                    }
                } else if ($action === 'updateProduct') {
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $price = $_POST['price'];
                    $stock = $_POST['stock'];
                    $sql = "UPDATE flowers SET name = ?, price = ?, stock = ? WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sdii", $name, $price, $stock, $id);
                    if ($stmt->execute()) {
                        logAction('update_product', "Updated product #$id: $name - Price: ₱$price, Stock: $stock");
                        echo '<div class="success-message">Product updated successfully</div>';
                    } else {
                        echo '<div class="error-message">Error updating product</div>';
                    }
                } else if ($action === 'deleteProduct') {
                    $id = $_POST['id'];
                    // Get product name before deletion for logging
                    $nameSql = "SELECT name FROM flowers WHERE id = ?";
                    $nameStmt = $conn->prepare($nameSql);
                    $nameStmt->bind_param("i", $id);
                    $nameStmt->execute();
                    $nameResult = $nameStmt->get_result();
                    $productName = $nameResult->fetch_assoc()['name'];

                    $checkSql = "SELECT COUNT(*) AS count FROM order_items WHERE flower_id = ?";
                    $checkStmt = $conn->prepare($checkSql);
                    $checkStmt->bind_param("i", $id);
                    $checkStmt->execute();
                    $checkResult = $checkStmt->get_result();
                    $row = $checkResult->fetch_assoc();

                    if ($row['count'] > 0) {
                        echo '<div class="error-message">Cannot delete this product because it is referenced by existing orders.</div>';
                    } else {
                        $sql = "DELETE FROM flowers WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $id);
                        if ($stmt->execute()) {
                            logAction('delete_product', "Deleted product: $productName (ID: $id)");
                            echo '<div class="success-message">Product deleted successfully</div>';
                        } else {
                            echo '<div class="error-message">Error deleting product.</div>';
                        }
                    }
                }
            }
        }
        ?>

        <div class="admin-container">
            <!-- Sidebar -->
            <aside class="admin-sidebar">
                <ul>
                    <li><a href="admin.php?page=orders" class="<?php echo $page === 'orders' ? 'active' : ''; ?>">📦 Orders</a></li>
                    <li><a href="admin.php?page=products" class="<?php echo $page === 'products' ? 'active' : ''; ?>">🌹 Products</a></li>
                    <li><a href="admin.php?page=inventory" class="<?php echo $page === 'inventory' ? 'active' : ''; ?>">📊 Inventory</a></li>
                    <li><a href="admin.php?page=history" class="<?php echo $page === 'history' ? 'active' : ''; ?>">📋 Activity History</a></li>
                    <li><a href="logout.php">🚪 Logout</a></li>
                </ul>
            </aside>

            <!-- Main Content -->
            <section class="admin-content">
                <?php
                if ($page === 'orders') {
                    // Display all orders
                    ?>
                    <h2>📦 Orders Management</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Total Price</th>
                                <th>Status</th>
                                <th>Order Date/Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM orders ORDER BY created_at DESC";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($order = $result->fetch_assoc()) {
                                    $statusBadgeClass = orderStatusClass($order['status']);
                                    $statusText = $order['status'];
                                    echo '
                                    <tr>
                                        <td>#' . $order['id'] . '</td>
                                        <td>' . $order['customer_name'] . '</td>
                                        <td>' . $order['customer_email'] . '</td>
                                        <td>' . $order['customer_phone'] . '</td>
                                        <td>₱' . number_format($order['total_price'], 2) . '</td>
                                        <td><span class="badge ' . $statusBadgeClass . '">' . $statusText . '</span></td>
                                        <td>' . date('M d, Y h:i A', strtotime($order['created_at'])) . '</td>
                                        <td>
                                            <div class="action-buttons">
                                                <button onclick="viewOrderDetails(' . $order['id'] . ')" class="btn btn-primary btn-sm">View</button>
                                                ' . ($order['status'] === 'Cancelled' ? '' : '<button onclick="editOrderStatus(' . $order['id'] . ')" class="btn btn-primary btn-sm">Edit</button>') . '
                                            </div>
                                        </td>
                                    </tr>
                                    ';
                                }
                            } else {
                                echo '<tr><td colspan="8" class="empty-state">No orders found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>

                    <!-- Modal for viewing order details -->
                    <div id="viewOrderModal" style="display:none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
                        <div style="background: white; margin: 2rem auto; padding: 2rem; border-radius: 8px; width: 90%; max-width: 800px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                                <h3>Order Details</h3>
                                <button type="button" onclick="closeViewModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">✕</button>
                            </div>

                            <!-- Customer Information -->
                            <div style="background: #f9f9f9; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem;">
                                <h4 style="margin-top: 0; color: #333;">Customer Information</h4>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Name:</label>
                                        <p id="detailCustomerName" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Email:</label>
                                        <p id="detailCustomerEmail" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Phone:</label>
                                        <p id="detailCustomerPhone" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Order Type:</label>
                                        <p id="detailOrderType" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                </div>
                                <div style="margin-top: 1rem;">
                                    <label style="font-weight: bold; color: #666;">Delivery Address:</label>
                                    <p id="detailCustomerAddress" style="margin: 0.5rem 0; color: #333;"></p>
                                </div>
                            </div>

                            <!-- Order Items -->
                            <div style="background: #f9f9f9; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem;">
                                <h4 style="margin-top: 0; color: #333;">Order Items</h4>
                                <table class="table" style="margin: 0;">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody id="detailOrderItems">
                                    </tbody>
                                </table>
                            </div>

                            <div id="detailCustomArrangement" style="display:none; background: #f9f9f9; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem;"></div>

                            <!-- Order Summary -->
                            <div style="background: #f9f9f9; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem;">
                                <h4 style="margin-top: 0; color: #333;">Order Summary</h4>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Order ID:</label>
                                        <p id="detailOrderId" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Total Price:</label>
                                        <p id="detailTotalPrice" style="margin: 0.5rem 0; color: #333; font-size: 1.2rem; font-weight: bold;"></p>
                                    </div>
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Status:</label>
                                        <p id="detailStatus" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                    <div>
                                        <label style="font-weight: bold; color: #666;">Order Date:</label>
                                        <p id="detailOrderDate" style="margin: 0.5rem 0; color: #333;"></p>
                                    </div>
                                </div>
                            </div>

                            <div style="display: flex; gap: 1rem;">
                                <button type="button" onclick="closeViewModal()" class="btn btn-danger">Close</button>
                            </div>
                        </div>
                    </div>

                    <!-- Modal for editing order status -->
                    <div id="editOrderModal" style="display:none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
                        <div style="background: white; padding: 2rem; border-radius: 8px; width: 90%; max-width: 400px;">
                            <h3>Update Order Status</h3>
                            <form method="POST">
                                <input type="hidden" name="action" value="updateOrderStatus">
                                <input type="hidden" id="editOrderId" name="orderId">
                                
                                <div class="form-group">
                                    <label for="statusSelect">Status:</label>
                                    <select id="statusSelect" name="status" required>
                                        <?php foreach (ORDER_STATUSES as $statusOption): ?>
                                            <option value="<?php echo htmlspecialchars($statusOption); ?>"><?php echo htmlspecialchars($statusOption); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn btn-success">Save</button>
                                    <button type="button" onclick="closeEditModal()" class="btn btn-danger">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php
                } else if ($page === 'products') {
                    // Display products with add/edit functionality
                    ?>
                    <h2>🌹 Products Management</h2>

                    <!-- Add Product Form -->
                    <div style="background: #f9f9f9; padding: 1.5rem; border-radius: 8px; margin-bottom: 2rem;">
                        <h3>Add New Product</h3>
                        <form method="POST" style="display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 1rem; align-items: flex-end;">
                            <input type="hidden" name="action" value="addProduct">
                            
                            <div class="form-group" style="margin: 0;">
                                <label for="productName">Product Name:</label>
                                <input type="text" id="productName" name="name" required>
                            </div>

                            <div class="form-group" style="margin: 0;">
                                <label for="productPrice">Price (₱):</label>
                                <input type="number" id="productPrice" name="price" step="0.01" min="0" required>
                            </div>

                            <div class="form-group" style="margin: 0;">
                                <label for="productStock">Stock Quantity:</label>
                                <input type="number" id="productStock" name="stock" min="0" required>
                            </div>

                            <button type="submit" class="btn btn-success">Add Product</button>
                        </form>
                    </div>

                    <!-- Products Table -->
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM flowers ORDER BY name";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($product = $result->fetch_assoc()) {
                                    echo '
                                    <tr>
                                        <td>#' . $product['id'] . '</td>
                                        <td>' . $product['name'] . '</td>
                                        <td>₱' . number_format($product['price'], 2) . '</td>
                                        <td>' . $product['stock'] . '</td>
                                        <td>
                                            <div class="action-buttons">
                                                <button type="button" class="btn btn-primary btn-sm"
                                                    data-id="' . $product['id'] . '"
                                                    data-name="' . htmlspecialchars($product['name'], ENT_QUOTES) . '"
                                                    data-price="' . $product['price'] . '"
                                                    data-stock="' . $product['stock'] . '"
                                                    onclick="editProductFromRow(this)">
                                                    Edit
                                                </button>
                                                <form method="POST" style="display:inline-block; margin:0;">
                                                    <input type="hidden" name="action" value="deleteProduct">
                                                    <input type="hidden" name="id" value="' . $product['id'] . '">
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm(\'Delete this product?\');">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    ';
                                }
                            } else {
                                echo '<tr><td colspan="5" class="empty-state">No products found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>

                    <!-- Modal for editing product -->
                    <div id="editProductModal" style="display:none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
                        <div style="background: white; padding: 2rem; border-radius: 8px; width: 90%; max-width: 400px;">
                            <h3>Edit Product</h3>
                            <form method="POST">
                                <input type="hidden" name="action" value="updateProduct">
                                <input type="hidden" id="editProductId" name="id">
                                
                                <div class="form-group">
                                    <label for="editProductName">Product Name:</label>
                                    <input type="text" id="editProductName" name="name" required>
                                </div>

                                <div class="form-group">
                                    <label for="editProductPrice">Price (₱):</label>
                                    <input type="number" id="editProductPrice" name="price" step="0.01" min="0" required>
                                </div>

                                <div class="form-group">
                                    <label for="editProductStock">Stock Quantity:</label>
                                    <input type="number" id="editProductStock" name="stock" min="0" required>
                                </div>

                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn btn-success">Save</button>
                                    <button type="button" onclick="closeProductModal()" class="btn btn-danger">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php
                } else if ($page === 'inventory') {
                    // Display inventory status
                    ?>
                    <h2>📊 Inventory Status</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Unit Price</th>
                                <th>Current Stock</th>
                                <th>Stock Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM flowers ORDER BY name";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($product = $result->fetch_assoc()) {
                                    $stockLevel = '';
                                    if ($product['stock'] <= 0) {
                                        $stockLevel = '<span class="badge" style="background-color: #f8d7da; color: #721c24;">Out of Stock</span>';
                                    } else if ($product['stock'] <= 20) {
                                        $stockLevel = '<span class="badge" style="background-color: #fff3cd; color: #856404;">Low Stock</span>';
                                    } else {
                                        $stockLevel = '<span class="badge" style="background-color: #d4edda; color: #155724;">In Stock</span>';
                                    }

                                    echo '
                                    <tr>
                                        <td>' . $product['name'] . '</td>
                                        <td>₱' . number_format($product['price'], 2) . '</td>
                                        <td>' . $product['stock'] . '</td>
                                        <td>' . $stockLevel . '</td>
                                    </tr>
                                    ';
                                }
                            } else {
                                echo '<tr><td colspan="4" class="empty-state">No products found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                    <?php
                } else if ($page === 'history') {
                    // Display activity history
                    ?>
                    <h2>📋 Activity History</h2>
                    <p style="color: #666; margin-bottom: 1rem;">View all staff and admin activities in the system.</p>

                    <table class="table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Action</th>
                                <th>Details</th>
                                <th>Source (IP / Browser)</th>
                                <th>Date & Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql = "SELECT al.*, u.username, CASE WHEN u.is_admin = 1 THEN 'admin' ELSE 'staff' END AS role FROM audit_logs al
                                    JOIN users u ON al.user_id = u.id
                                    ORDER BY al.created_at DESC LIMIT 100";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($log = $result->fetch_assoc()) {
                                    $userBadge = '';
                                    if ($log['role'] === 'admin') {
                                        $userBadge = '<span class="badge" style="background: #dc3545; color: white;">' . htmlspecialchars($log['username']) . '</span>';
                                    } elseif ($log['role'] === 'staff') {
                                        $userBadge = '<span class="badge" style="background: #007bff; color: white;">' . htmlspecialchars($log['username']) . '</span>';
                                    } else {
                                        $userBadge = htmlspecialchars($log['username']);
                                    }

                                    echo '
                                    <tr>
                                        <td>' . $userBadge . '</td>
                                        <td>' . ucwords(str_replace('_', ' ', $log['action'])) . '</td>
                                        <td>' . htmlspecialchars($log['details']) . '</td>
                                        <td>' . htmlspecialchars($log['ip_address']) . '</td>
                                        <td>' . date('M d, Y h:i A', strtotime($log['created_at'])) . '</td>
                                    </tr>
                                    ';
                                }
                            } else {
                                echo '<tr><td colspan="5" class="empty-state">No activity logs found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                    <?php
                }
                ?>
            </section>
        </div>
    </main>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> L&C Flowershop. All rights reserved.</p>
    </footer>

    <script>
        function editOrderStatus(orderId) {
            document.getElementById('editOrderId').value = orderId;
            document.getElementById('editOrderModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editOrderModal').style.display = 'none';
        }

        function viewOrderDetails(orderId) {
            // Fetch order details via AJAX
            fetch('api/orders.php?action=getOrderDetails&orderId=' + orderId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const order = data.order;
                        const items = data.items;

                        // Populate customer information
                        document.getElementById('detailCustomerName').textContent = order.customer_name;
                        document.getElementById('detailCustomerEmail').textContent = order.customer_email;
                        document.getElementById('detailCustomerPhone').textContent = order.customer_phone;
                        document.getElementById('detailCustomerAddress').textContent = order.customer_address;
                        document.getElementById('detailOrderType').textContent = order.order_type === 'delivery' ? 'Delivery' : 'Pickup';

                        // Populate order items and custom arrangement details from the same order-item records.
                        const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
                        const itemsHtml = items.map(item => `
                            <tr>
                                <td>${escapeHtml(item.name)}</td>
                                <td>${item.quantity}</td>
                                <td>₱${parseFloat(item.unit_price).toFixed(2)}</td>
                                <td>₱${parseFloat(item.subtotal).toFixed(2)}</td>
                            </tr>
                        `).join('');
                        document.getElementById('detailOrderItems').innerHTML = itemsHtml;

                        const customItem = items.find(item => item.custom_style || item.base_name);
                        const customDetails = document.getElementById('detailCustomArrangement');
                        if (customItem) {
                            const imageHtml = customItem.inspiration_image
                                ? `<img src="${escapeHtml(customItem.inspiration_image)}" alt="Customer Inspiration / Reference Image" style="max-width: 260px; max-height: 260px; object-fit: contain; border-radius: 6px; border: 1px solid #ddd; display: block; margin-top: 0.5rem;">`
                                : '<p>No inspiration image provided.</p>';
                            const notesHtml = customItem.custom_notes
                                ? `<p style="white-space: pre-wrap;">${escapeHtml(customItem.custom_notes)}</p>`
                                : '<p>No additional notes provided.</p>';
                            customDetails.innerHTML = `
                                <h4 style="margin-top: 0; color: #333;">Custom Arrangement Details</h4>
                                <p><strong>Style Selection:</strong> ${customItem.custom_style === 'inspiration' ? 'Upload an Inspiration Photo (Custom Peg)' : 'Select Your Flowers (Stylist\'s Choice)'}</p>
                                <p><strong>Base:</strong> ${escapeHtml(customItem.base_name || 'Base information unavailable')}</p>
                                <p><strong>Customer Inspiration / Reference Image:</strong></p>${imageHtml}
                                <p><strong>Customization Waiver:</strong> ${customItem.custom_style === 'inspiration' ? (Number(customItem.waiver_agreed) === 1 ? 'Agreed' : 'Not agreed') : 'Not applicable'}</p>
                                <p><strong>Customer's Additional Notes / Special Requests:</strong></p>${notesHtml}
                            `;
                            customDetails.style.display = 'block';
                        } else {
                            customDetails.style.display = 'none';
                            customDetails.innerHTML = '';
                        }

                        // Populate order summary
                        document.getElementById('detailOrderId').textContent = '#' + order.id;
                        document.getElementById('detailTotalPrice').textContent = '₱' + parseFloat(order.total_price).toFixed(2);
                        const statusText = order.status;
                        const statusBadgeClass = 'badge-' + order.status.toLowerCase().replace(/[^a-z0-9]+/g, '-');
                        document.getElementById('detailStatus').innerHTML = `<span class="badge ${statusBadgeClass}">${statusText}</span>`;
                        document.getElementById('detailOrderDate').textContent = new Date(order.created_at).toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Manila' });

                        // Show modal
                        document.getElementById('viewOrderModal').style.display = 'block';
                    } else {
                        alert('Error loading order details');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading order details');
                });
        }

        function closeViewModal() {
            document.getElementById('viewOrderModal').style.display = 'none';
        }

        function editProduct(id, name, price, stock) {
            document.getElementById('editProductId').value = id;
            document.getElementById('editProductName').value = name;
            document.getElementById('editProductPrice').value = price;
            document.getElementById('editProductStock').value = stock;
            document.getElementById('editProductModal').style.display = 'flex';
        }

        function editProductFromRow(button) {
            editProduct(button.dataset.id, button.dataset.name, button.dataset.price, button.dataset.stock);
        }

        function closeProductModal() {
            document.getElementById('editProductModal').style.display = 'none';
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const editOrderModal = document.getElementById('editOrderModal');
            const editProductModal = document.getElementById('editProductModal');
            const viewOrderModal = document.getElementById('viewOrderModal');
            
            if (event.target === editOrderModal) {
                editOrderModal.style.display = 'none';
            }
            if (event.target === editProductModal) {
                editProductModal.style.display = 'none';
            }
            if (event.target === viewOrderModal) {
                viewOrderModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
