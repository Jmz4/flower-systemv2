# 🚀 Quick Start Guide

## First-Time Setup (Do This First!)

### Step 1: Start Your Local Server
- **XAMPP Users**: Click "Start" for Apache and MySQL
- **WAMP Users**: Start WAMP Server
- **LAMP Users**: Start Apache and MySQL services

### Step 2: Copy Files to Web Directory
Copy all files to:
- XAMPP: `C:\xampp\htdocs\flower_shop\`
- WAMP: `C:\wamp\www\flower_shop\`
- LAMP: `/var/www/html/flower_shop/`

### Step 3: Initialize Database
**Open in your browser:**
```
http://localhost/flower_shop/setup_db.php
```

You should see:
```
Database created successfully
Database setup completed successfully!
```

✅ If you see this, the database is ready!

### Step 4: Access the Application

#### Customer Store:
```
http://localhost/flower_shop/index.php
```

#### Admin Panel:
```
http://localhost/flower_shop/admin.php
```

Login with:
- Username: `admin`
- Password: `admin123`

---

## What To Do Next

### 1. Explore the Store (index.php)
- Browse pre-designed bouquets
- Create a custom arrangement
- Add items to cart
- Try checkout

### 2. Visit Admin Panel (admin.php)
- View orders (there will be one from your test purchase)
- See inventory levels
- Add/edit products
- Update order status

### 3. Test All Features
- ✅ Create custom arrangements
- ✅ Add bouquets to cart
- ✅ Place an order
- ✅ Update order status in admin
- ✅ Check inventory

---

## File Quick Reference

| File | Purpose |
|------|---------|
| `setup_db.php` | 🔧 Database initialization (run once) |
| `index.php` | 🌸 Main store page |
| `cart.php` | 🛒 Shopping cart |
| `login.php` | 🔐 Admin login |
| `admin.php` | 👨‍💼 Admin dashboard |
| `api.php` | 🔌 Backend API |
| `script.js` | ⚡ Frontend interactions |
| `style.css` | 🎨 Styling |
| `config.php` | ⚙️ Database config |

---

## Common Issues & Solutions

### Issue: "Connection failed: Unknown database"
**Solution:** Run `http://localhost/flower_shop/setup_db.php`

### Issue: Cart not working
**Solution:** Refresh browser or clear cache (Ctrl+Shift+Delete)

### Issue: Can't login as admin
**Solution:** 
1. Make sure setup_db.php was run
2. Username: `admin` (exact)
3. Password: `admin123` (exact)

### Issue: "Table not found" error
**Solution:** Delete database and run setup_db.php again

---

## Key Features to Test

### 1. Real-Time Price Calculation
- Add flowers to custom arrangement
- Watch price update automatically

### 2. Stock Management
- Try ordering more flowers than available
- See error message

### 3. Pre-Designed Bouquets
- Browse 3 sample bouquets
- Add to cart with one click

### 4. Occasion Suggestions
- Select an occasion
- See flower recommendations

### 5. Admin Functions
- View orders
- Change order status
- Add new products
- Check inventory levels

---

## Sample Test Order

1. Go to `http://localhost/flower_shop/index.php`
2. Select base: "Bouquet" ($5.00)
3. Add flowers:
   - 5x Rose ($2.50) = $12.50
   - 3x Tulip ($1.80) = $5.40
4. Total: $22.90
5. Go to cart → Fill checkout details
6. Place order
7. Go to admin panel → See order in Orders list

---

## Database Credentials

Edit `config.php` if your database settings are different:

```php
define('DB_HOST', 'localhost');  // Usually 'localhost'
define('DB_USER', 'root');       // Default MySQL user
define('DB_PASS', '');           // Password (usually empty for local)
define('DB_NAME', 'flower_shop'); // Database name
```

---

## Admin Login

**Always use these credentials:**
- Username: `admin`
- Password: `admin123`

Change password in database if needed:
```sql
UPDATE users SET password = PASSWORD('newpassword') WHERE username = 'admin';
```

---

## Default Data

### Flowers Available:
- Rose ($2.50)
- Tulip ($1.80)
- Sunflower ($2.00)
- Daisy ($1.50)
- Lily ($3.00)
- Orchid ($4.00)
- Carnation ($1.20)
- Lavender ($2.20)

### Bases:
- Bouquet ($5.00)
- Vase ($8.00)
- Box ($6.00)

### Pre-Designed Bouquets:
- Romantic Love Bouquet ($35.00)
- Happy Birthday Bouquet ($28.00)
- Sympathy Bouquet ($32.00)

---

## Need Help?

1. **Check README.md** for detailed documentation
2. **Review error messages** in browser console (F12)
3. **Verify setup_db.php ran** successfully
4. **Ensure Apache & MySQL are running**
5. **Clear browser cache** if pages look wrong

---

## You're All Set! 🎉

Start with `http://localhost/flower_shop/` and explore the system!

Happy flower shopping! 🌸
