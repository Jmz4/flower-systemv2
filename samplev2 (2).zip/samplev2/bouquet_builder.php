<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bouquet Builder - Flower Shop</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        .container {
            max-width: 1200px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #667eea;
            margin-bottom: 30px;
        }

        .builder-section {
            display: flex;
            justify-content: space-between;
            width: 100%;
            margin-bottom: 20px;
        }

        .flower-list {
            flex: 1;
            margin-right: 20px;
        }

        .flower-list h2 {
            text-align: center;
            margin-bottom: 15px;
        }

        .flowers {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
        }

        .flower {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            overflow: hidden;
            cursor: grab;
            transition: transform 0.2s;
            border: 2px solid #ddd;
        }

        .flower:hover {
            transform: scale(1.1);
        }

        .flower img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .bouquet-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .bouquet-container {
            width: 300px;
            height: 300px;
            border: 2px dashed #667eea;
            border-radius: 10px;
            position: relative;
            background: #f9f9f9;
            margin-bottom: 20px;
        }

        .bouquet-flower {
            position: absolute;
            width: 60px;
            height: 60px;
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .bouquet-flower img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .price-display {
            font-size: 24px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }

        .clear-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.2s;
        }

        .clear-btn:hover {
            background: #c82333;
        }

        .flower-info {
            position: absolute;
            bottom: 5px;
            left: 5px;
            background: rgba(255,255,255,0.8);
            padding: 2px 5px;
            border-radius: 3px;
            font-size: 12px;
            display: none;
        }

        .flower:hover .flower-info {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Build Your Bouquet</h1>
        <div class="builder-section">
            <div class="flower-list">
                <h2>Available Flowers</h2>
                <div class="flowers" id="flowerList"></div>
            </div>
            <div class="bouquet-area">
                <div class="bouquet-container" id="bouquetContainer"></div>
                <div class="price-display">Total: ₱<span id="totalPrice">0.00</span></div>
                <button class="clear-btn" onclick="clearBouquet()">Clear Bouquet</button>
            </div>
        </div>
    </div>

    <script>
        const flowers = [
            { name: 'Rose', price: 50, image: 'flowerimage/flowersrose.jfif' },
            { name: 'Tulip', price: 40, image: 'flowerimage/flowerstulip.jfif' },
            { name: 'Sunflower', price: 30, image: 'flowerimage/flowerssunflower.jfif' },
            { name: 'Lily', price: 45, image: 'flowerimage/flowerslily.jfif' },
            { name: 'Daisy', price: 25, image: 'flowerimage/flowersdaisy.jfif' },
            { name: 'Lavender', price: 35, image: 'flowerimage/flowerslavender.jfif' },
            { name: 'Orchid', price: 60, image: 'flowerimage/flowersorchid.jfif' },
            { name: 'Carnation', price: 20, image: 'flowerimage/flowerscarnation.jfif' }
        ];

        const positions = [
            { left: '50%', top: '50%', zIndex: 10 },
            { left: '25%', top: '50%', zIndex: 9 },
            { left: '75%', top: '50%', zIndex: 8 },
            { left: '50%', top: '25%', zIndex: 7 },
            { left: '37.5%', top: '37.5%', zIndex: 6 },
            { left: '62.5%', top: '37.5%', zIndex: 5 },
            { left: '50%', top: '75%', zIndex: 4 },
            { left: '50%', top: '50%', zIndex: 3 }
        ];

        let bouquetFlowers = [];
        let totalPrice = 0;

        function init() {
            const flowerList = document.getElementById('flowerList');
            flowers.forEach((flower, index) => {
                const flowerDiv = document.createElement('div');
                flowerDiv.className = 'flower';
                flowerDiv.draggable = true;
                flowerDiv.dataset.index = index;
                flowerDiv.innerHTML = `
                    <img src="${flower.image}" alt="${flower.name}">
                    <div class="flower-info">${flower.name}<br>₱${flower.price}</div>
                `;
                flowerDiv.addEventListener('dragstart', dragStart);
                flowerList.appendChild(flowerDiv);
            });

            const bouquetContainer = document.getElementById('bouquetContainer');
            bouquetContainer.addEventListener('dragover', dragOver);
            bouquetContainer.addEventListener('drop', drop);
        }

        function dragStart(e) {
            e.dataTransfer.setData('text/plain', e.target.dataset.index);
        }

        function dragOver(e) {
            e.preventDefault();
        }

        function drop(e) {
            e.preventDefault();
            const index = e.dataTransfer.getData('text/plain');
            if (index && bouquetFlowers.length < 8) {
                addFlowerToBouquet(parseInt(index));
            }
        }

        function addFlowerToBouquet(index) {
            const flower = flowers[index];
            bouquetFlowers.push(flower);
            totalPrice += flower.price;
            updateDisplay();

            const bouquetContainer = document.getElementById('bouquetContainer');
            const flowerDiv = document.createElement('div');
            flowerDiv.className = 'bouquet-flower';
            const pos = positions[bouquetFlowers.length - 1];
            const rotation = Math.random() * 20 - 10;
            flowerDiv.style.left = pos.left;
            flowerDiv.style.top = pos.top;
            flowerDiv.style.zIndex = pos.zIndex;
            flowerDiv.style.transform = `translate(-50%, -50%) rotate(${rotation}deg)`;
            flowerDiv.innerHTML = `<img src="${flower.image}" alt="${flower.name}">`;
            bouquetContainer.appendChild(flowerDiv);
        }

        function clearBouquet() {
            bouquetFlowers = [];
            totalPrice = 0;
            updateDisplay();
            const bouquetContainer = document.getElementById('bouquetContainer');
            bouquetContainer.innerHTML = '';
        }

        function updateDisplay() {
            document.getElementById('totalPrice').textContent = totalPrice.toFixed(2);
        }

        document.addEventListener('DOMContentLoaded', init);
    </script>
</body>
</html>