<?php
require_once 'config.php';

// Set response header to JSON
header('Content-Type: application/json');

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'getBases':
        getBases();
        break;
    case 'getFlowers':
        getFlowers();
        break;
    case 'getBouquets':
        getBouquets();
        break;
    case 'createOrder':
        createOrder();
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}

// Get all bases
function getBases() {
    global $conn;
    $sql = "SELECT id, name, price FROM bases";
    $result = $conn->query($sql);
    
    $bases = [];
    while ($row = $result->fetch_assoc()) {
        $bases[] = $row;
    }
    
    echo json_encode($bases);
}

// Get all flowers with stock
function getFlowers() {
    global $conn;
    $sql = "SELECT id, name, price, stock FROM flowers WHERE stock > 0";
    $result = $conn->query($sql);
    
    $flowers = [];
    while ($row = $result->fetch_assoc()) {
        $flowers[] = $row;
    }
    
    echo json_encode($flowers);
}

// Get pre-designed bouquets with items
function getBouquets() {
    global $conn;
    // include image column so frontend can use uploaded images stored in flowerimage/
    $sql = "SELECT b.id, b.name, b.description, b.price, b.base_id, b.image FROM bouquets b";
    $result = $conn->query($sql);
    
    $bouquets = [];
    while ($row = $result->fetch_assoc()) {
        // Get bouquet items
        $itemsSql = "SELECT f.name, bi.quantity FROM bouquet_items bi
                     JOIN flowers f ON bi.flower_id = f.id
                     WHERE bi.bouquet_id = ?";
        $stmtItems = $conn->prepare($itemsSql);
        $stmtItems->bind_param("i", $row['id']);
        $stmtItems->execute();
        $itemsResult = $stmtItems->get_result();
        
        $items = [];
        while ($item = $itemsResult->fetch_assoc()) {
            $items[] = $item['name'] . ' × ' . $item['quantity'];
        }
        
        $row['items'] = implode(', ', $items);
        $bouquets[] = $row;
    }

    // Also include any uploaded images in the flowerimage/ folder that are not yet
    // represented in the bouquets table. We will prepend these so uploaded images
    // appear first in the Pre-Designed Bouquets section.
    $uploadedBouquets = [];
    $imageDir = __DIR__ . '/flowerimage/';
    if (is_dir($imageDir)) {
        $files = scandir($imageDir);
        // mapping of specific filenames to friendly names (lowercase keys)
        $nameMap = [
            'lcflower12.jpg' => 'The Beautiful You',
            'lcflower13.jpg' => 'Radiant Bloom',
            'lcflower1.jpg' => 'Sunset Bliss',
            'lcflower2.jpg' => 'Golden Embrace',
            'lcflower3.jpg' => 'Rosy Whisper',
            'lcflower4.jpg' => 'Pastel Dream',
            'lcflower5.jpg' => 'Sweet Serenade',
            'lcflower6.jpg' => 'Pink Promise',
            'lcflower7.jpg' => 'Lavender Luxe',
            'lcflower8.jpg' => 'Sunny Delight',
            'lcflower9.jpg' => 'Honey Glow',
            'lcflower10.jpg' => 'Crimson Charm',
            'lcflower11.jpg' => 'Purple Haze'
        ];

        // Build set of existing images to avoid duplicates (case-insensitive)
        $existingImages = array_map(function($b) { return isset($b['image']) ? strtolower($b['image']) : null; }, $bouquets);

        foreach ($files as $f) {
            if ($f === '.' || $f === '..') continue;
            $lower = strtolower($f);
            // target our uploaded lcflower* images
            if (!preg_match('/^lcflower\d+\.(jpg|jpeg|jfif|png)$/i', $lower)) continue;
            if (in_array($lower, $existingImages)) continue;

            $friendly = isset($nameMap[$lower]) ? $nameMap[$lower] : ucwords(str_replace(['-', '_', '.jpg', '.jfif', '.jpeg', '.png'], [' ', ' ', '', '', '', ''], $f));

                // price mapping for uploaded images (reasonable shop prices)
                $priceMap = [
                    'lcflower1.jpg' => 550.00,
                    'lcflower2.jpg' => 450.00,
                    'lcflower3.jpg' => 650.00,
                    'lcflower4.jpg' => 400.00,
                    'lcflower5.jpg' => 500.00,
                    'lcflower6.jpg' => 480.00,
                    'lcflower7.jpg' => 600.00,
                    'lcflower8.jpg' => 420.00,
                    'lcflower9.jpg' => 470.00,
                    'lcflower10.jpg' => 700.00,
                    'lcflower11.jpg' => 530.00,
                    'lcflower12.jpg' => 750.00,
                    'lcflower13.jpg' => 680.00
                ];

                $price = isset($priceMap[$lower]) ? $priceMap[$lower] : 450.00;

                $uploadedBouquets[] = [
                    'id' => null,
                    'name' => $friendly,
                    'description' => 'Pre-designed bouquet',
                    'price' => $price,
                    'base_id' => 1,
                    'image' => $f,
                    'items' => ''
                ];
        }

        // Prepend uploaded bouquets so they appear first
        if (!empty($uploadedBouquets)) {
            $bouquets = array_merge($uploadedBouquets, $bouquets);
        }
    }
    
    echo json_encode($bouquets);
}

// Create order
function createOrder() {
    global $conn;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $customerName = $input['customerName'] ?? '';
    $customerEmail = $input['customerEmail'] ?? '';
    $customerPhone = $input['customerPhone'] ?? '';
    $customerAddress = $input['customerAddress'] ?? '';
    $orderType = $input['orderType'] ?? 'delivery';
    $cart = $input['cart'] ?? [];
    
    // Validate input
    if (empty($customerName) || empty($customerEmail) || empty($customerPhone) || empty($customerAddress)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        return;
    }
    
    if (empty($cart)) {
        echo json_encode(['success' => false, 'message' => 'Cart is empty']);
        return;
    }
    
    // Calculate total price
    $totalPrice = 0;
    foreach ($cart as $item) {
        $totalPrice += $item['type'] === 'custom' ? $item['total'] : $item['price'];
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Associate orders with the signed-in customer so My Orders can retrieve them.
        $userId = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
        if ($userId) {
            $sql = "INSERT INTO orders (user_id, customer_name, customer_email, customer_phone, customer_address, order_type, total_price, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isssssd", $userId, $customerName, $customerEmail, $customerPhone, $customerAddress, $orderType, $totalPrice);
        } else {
            $sql = "INSERT INTO orders (customer_name, customer_email, customer_phone, customer_address, order_type, total_price, status)
                VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssd", $customerName, $customerEmail, $customerPhone, $customerAddress, $orderType, $totalPrice);
        }
        $stmt->execute();
        
        $orderId = $stmt->insert_id;
        
        // Insert order items and deduct stock
        foreach ($cart as $cartItem) {
            if ($cartItem['type'] === 'custom') {
                // Custom arrangement
                $baseId = $cartItem['base']['id'];
                $subtotal = $cartItem['total'];
                $style = ($cartItem['style'] ?? '') === 'inspiration' ? 'inspiration' : 'flowers';
                $notes = substr((string) ($cartItem['notes'] ?? ''), 0, 10000);
                $inspirationImage = $style === 'inspiration' ? (string) ($cartItem['inspirationImage'] ?? '') : '';
                $waiverAgreed = $style === 'inspiration' && !empty($cartItem['waiverAgreed']) ? 1 : 0;
                if ($style === 'inspiration' && (!$inspirationImage || !$waiverAgreed)) {
                    throw new Exception('The inspiration image and customization agreement are required.');
                }
                if ($inspirationImage && !preg_match('#^flowerimage/custom_uploads/[A-Za-z0-9_-]+\.(?:jpg|jpeg|png)$#i', $inspirationImage)) {
                    throw new Exception('The inspiration image reference is invalid.');
                }
                
                $sql = "INSERT INTO order_items (order_id, item_type, base_id, quantity, unit_price, subtotal, custom_style, custom_notes, inspiration_image, waiver_agreed)
                        VALUES (?, 'flower', ?, 1, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("iiddsssi", $orderId, $baseId, $subtotal, $subtotal, $style, $notes, $inspirationImage, $waiverAgreed);
                $stmt->execute();
                
                // Add flowers in the arrangement
                foreach ($cartItem['flowers'] as $flower) {
                    $flowerId = $flower['id'];
                    $quantity = $flower['quantity'];
                    $unitPrice = $flower['price'];
                    $flowerSubtotal = $quantity * $unitPrice;
                    
                    // Add order item
                    $sql = "INSERT INTO order_items (order_id, item_type, flower_id, quantity, unit_price, subtotal)
                            VALUES (?, 'flower', ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("iiiddd", $orderId, $flowerId, $quantity, $unitPrice, $flowerSubtotal);
                    $stmt->execute();
                    
                    // Deduct stock
                    $sql = "UPDATE flowers SET stock = stock - ? WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ii", $quantity, $flowerId);
                    $stmt->execute();
                }
            } else if ($cartItem['type'] === 'bouquet') {
                // Pre-designed bouquet
                $bouquetId = $cartItem['bouquetId'] ?? null;
                $bouquetPrice = $cartItem['price'];
                $quantity = $cartItem['quantity'];

                $subtotal = $bouquetPrice * $quantity;

                if ($bouquetId === null || $bouquetId === '' || !is_numeric($bouquetId)) {
                    // Bouquet is an uploaded item not present in the `bouquets` table.
                    // Insert order item with NULL bouquet_id to avoid FK constraint.
                    $sql = "INSERT INTO order_items (order_id, item_type, bouquet_id, quantity, unit_price, subtotal) VALUES (?, 'bouquet', NULL, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("iidd", $orderId, $quantity, $bouquetPrice, $subtotal);
                    $stmt->execute();
                    // No stock deduction because bouquet composition is not in DB
                } else {
                    // Bouquet exists in DB — reference it and deduct stock
                    $sql = "INSERT INTO order_items (order_id, item_type, bouquet_id, quantity, unit_price, subtotal) VALUES (?, 'bouquet', ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("iiidd", $orderId, $bouquetId, $quantity, $bouquetPrice, $subtotal);
                    $stmt->execute();

                    // Deduct stock for flowers in bouquet
                    $sql = "SELECT flower_id, quantity FROM bouquet_items WHERE bouquet_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $bouquetId);
                    $stmt->execute();
                    $itemsResult = $stmt->get_result();

                    while ($item = $itemsResult->fetch_assoc()) {
                        $flowerQuantity = $item['quantity'] * $quantity; // quantity of flower in bouquet times quantity of bouquets ordered
                        $flowerID = $item['flower_id'];

                        // Deduct stock
                        $sql = "UPDATE flowers SET stock = stock - ? WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ii", $flowerQuantity, $flowerID);
                        $stmt->execute();
                    }
                }
            }
        }
        
        $conn->commit();
        echo json_encode(['success' => true, 'orderId' => $orderId]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Error creating order: ' . $e->getMessage()]);
    }
}
?>
