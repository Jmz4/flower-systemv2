<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = intval($_SESSION['user_id']);
$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');

// Handle order cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancelOrder') {
    $orderId = intval($_POST['order_id'] ?? 0);
    $updateSql = "UPDATE orders SET status = 'Cancelled' WHERE id = ? AND user_id = ? AND status IN ('Pending', 'Confirmed')";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param('ii', $orderId, $userId);
    $updateStmt->execute();
    if ($updateStmt->affected_rows === 1) {
        echo '<div class="success-message">Order cancelled successfully.</div>';
    } else {
        echo '<div class="error-message">This order can no longer be cancelled because it is already being prepared or processed.</div>';
    }
}

$orders = [];
$sql = "SELECT id, customer_name, customer_email, customer_phone, customer_address, total_price, status, created_at FROM orders WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}
$orderCount = count($orders);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="myorders.php">My Orders <span id="order-count"><?php echo $orderCount; ?></span></a></li>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if (isAdminOrStaff()): ?>
                        <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                    <li class="nav-user">Welcome, <?php echo $username; ?></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <section class="welcome">
            <h1>My Orders</h1>
            <p>Hi <?php echo $username; ?>, this page shows your order history and current status.</p>
        </section>

        <?php if (empty($orders)): ?>
            <div class="empty-state" style="background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.08);">
                <p class="empty-state-icon">🧾</p>
                <p>You have no orders yet.</p>
                <p><a href="index.php" class="btn btn-primary">Start Shopping</a></p>
            </div>
        <?php else: ?>
            <div class="admin-content" style="padding: 1.5rem;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?php echo $order['id']; ?></td>
                                <td><?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></td>
                                <td>₱<?php echo number_format($order['total_price'], 2); ?></td>
                                <td><span class="badge <?php echo htmlspecialchars(orderStatusClass($order['status'])); ?>"><?php
                                    $statusText = htmlspecialchars($order['status']);
                                    echo $statusText;
                                ?></span></td>
                                <td>
                                    <details>
                                        <summary>View receipt</summary>
                                        <div style="margin-top: 0.75rem;">
                                            <p><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                                            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email']); ?></p>
                                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($order['customer_phone']); ?></p>
                                            <p><strong>Address:</strong> <?php echo nl2br(htmlspecialchars($order['customer_address'])); ?></p>
                                            <p><strong>Items:</strong></p>
                                            <ul>
                                                <?php
                                                $itemSql = "SELECT item_type, flower_id, bouquet_id, base_id, quantity, unit_price, subtotal, custom_style, custom_notes, inspiration_image, waiver_agreed FROM order_items WHERE order_id = ?";
                                                $itemStmt = $conn->prepare($itemSql);
                                                $itemStmt->bind_param('i', $order['id']);
                                                $itemStmt->execute();
                                                $itemResult = $itemStmt->get_result();

                                                while ($item = $itemResult->fetch_assoc()):
                                                    if ($item['item_type'] === 'bouquet') {
                                                        $nameSql = "SELECT name FROM bouquets WHERE id = ?";
                                                        $nameStmt = $conn->prepare($nameSql);
                                                        $nameStmt->bind_param('i', $item['bouquet_id']);
                                                        $nameStmt->execute();
                                                        $nameRes = $nameStmt->get_result()->fetch_assoc();
                                                        $itemName = $nameRes['name'] ?? 'Bouquet';
                                                    } elseif ($item['item_type'] === 'flower') {
                                                        if (!empty($item['flower_id'])) {
                                                            $nameSql = "SELECT name FROM flowers WHERE id = ?";
                                                            $nameStmt = $conn->prepare($nameSql);
                                                            $nameStmt->bind_param('i', $item['flower_id']);
                                                            $nameStmt->execute();
                                                            $nameRes = $nameStmt->get_result()->fetch_assoc();
                                                            $itemName = $nameRes['name'] ?? 'Flower';
                                                        } elseif (!empty($item['base_id'])) {
                                                            $nameSql = "SELECT name FROM bases WHERE id = ?";
                                                            $nameStmt = $conn->prepare($nameSql);
                                                            $nameStmt->bind_param('i', $item['base_id']);
                                                            $nameStmt->execute();
                                                            $nameRes = $nameStmt->get_result()->fetch_assoc();
                                                            $itemName = 'Base: ' . ($nameRes['name'] ?? 'Base');
                                                        } else {
                                                            $itemName = 'Custom item';
                                                        }
                                                    } else {
                                                        $itemName = 'Item';
                                                    }
                                                ?>
                                                    <li>
                                                        <?php echo htmlspecialchars($itemName); ?> × <?php echo $item['quantity']; ?> — ₱<?php echo number_format($item['subtotal'], 2); ?>
                                                        <?php if (!empty($item['custom_style'])): ?>
                                                            <br><small><strong>Style:</strong> <?php echo $item['custom_style'] === 'inspiration' ? 'Upload an Inspiration Photo (Custom Peg)' : 'Select Your Flowers (Stylist’s Choice)'; ?></small>
                                                            <?php if ($item['custom_style'] === 'inspiration'): ?>
                                                                <br><small><strong>Waiver:</strong> <?php echo !empty($item['waiver_agreed']) ? 'Agreed' : 'Not agreed'; ?></small>
                                                                <?php if (!empty($item['inspiration_image'])): ?><br><small><a href="<?php echo htmlspecialchars($item['inspiration_image']); ?>" target="_blank" rel="noopener">View inspiration image</a></small><?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if ($item['custom_notes'] !== null && $item['custom_notes'] !== ''): ?><br><small><strong>Notes:</strong> <?php echo nl2br(htmlspecialchars($item['custom_notes'])); ?></small><?php endif; ?>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endwhile; ?>
                                            </ul>
                                        </div>
                                    </details>
                                    <?php if (isCustomerCancellableStatus($order['status'])): ?>
                                        <form method="POST" style="display:inline-block; margin-top: 0.5rem;">
                                            <input type="hidden" name="action" value="cancelOrder">
                                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to cancel this order?');">Cancel Order</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2024 Flower Shop. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const orderCount = <?php echo $orderCount; ?>;
            const countBadge = document.getElementById('order-count');
            if (countBadge) {
                countBadge.textContent = orderCount;
            }
        });
    </script>
</body>
</html>
