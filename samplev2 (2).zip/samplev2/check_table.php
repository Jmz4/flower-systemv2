<?php
$conn = new mysqli('localhost', 'root', '');
$conn->select_db('flower_shop');
$result = $conn->query('DESCRIBE flowers');
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . ' - ' . $row['Type'] . ' - ' . $row['Key'] . PHP_EOL;
}
$conn->close();
?>