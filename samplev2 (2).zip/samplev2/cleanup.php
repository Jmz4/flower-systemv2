<?php
$conn = new mysqli('localhost', 'root', '');
$conn->select_db('flower_shop');

// Delete old flower prices (keeping the higher ones)
$conn->query('DELETE FROM flowers WHERE (name = "Rose" AND price = 2.50) OR (name = "Tulip" AND price = 1.80) OR (name = "Sunflower" AND price = 2.00) OR (name = "Daisy" AND price = 1.50) OR (name = "Lily" AND price = 3.00) OR (name = "Orchid" AND price = 4.00) OR (name = "Carnation" AND price = 1.20) OR (name = "Lavender" AND price = 2.20)');

// Delete duplicate bouquets
$conn->query('DELETE b1 FROM bouquets b1 INNER JOIN bouquets b2 WHERE b1.id > b2.id AND b1.name = b2.name');

echo 'Duplicates removed';
$conn->close();
?>