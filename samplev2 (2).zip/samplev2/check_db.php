<?php
$conn = new mysqli('localhost', 'root', '');
$conn->select_db('flower_shop');

$result = $conn->query('SELECT COUNT(*) as count FROM bouquets');
$row = $result->fetch_assoc();
echo 'Bouquet count: ' . $row['count'] . PHP_EOL;

$result = $conn->query('SELECT COUNT(*) as count FROM flowers');
$row = $result->fetch_assoc();
echo 'Flower count: ' . $row['count'] . PHP_EOL;

$result = $conn->query('SELECT COUNT(*) as count FROM bases');
$row = $result->fetch_assoc();
echo 'Base count: ' . $row['count'] . PHP_EOL;

$conn->close();
?>