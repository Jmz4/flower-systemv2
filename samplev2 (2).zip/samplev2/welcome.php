<?php
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['is_admin']) {
        header('Location: admin.php');
    } else {
        header('Location: index.php');
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - L&C Flowershop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .welcome-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            padding: 2rem;
            position: relative;
        }

        .welcome-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.4);
            padding: 4rem;
            max-width: 1000px;
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .welcome-content {
            text-align: left;
        }

        .welcome-title {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 1.5rem;
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        .welcome-subtitle {
            font-size: 1.4rem;
            color: #555;
            margin-bottom: 2rem;
            line-height: 1.6;
            font-weight: 600;
        }

        .welcome-description {
            font-size: 1.05rem;
            color: #777;
            margin-bottom: 2rem;
            line-height: 1.9;
            text-align: justify;
        }

        .welcome-features {
            margin-bottom: 2rem;
        }

        .feature-item {
            display: flex;
            align-items: center;
            margin-bottom: 1.2rem;
            font-size: 1rem;
            color: #666;
            font-weight: 500;
        }

        .feature-icon {
            font-size: 1.8rem;
            margin-right: 1.2rem;
            color: #667eea;
            min-width: 40px;
            text-align: center;
        }

        .welcome-buttons {
            display: flex;
            gap: 1.5rem;
            margin-top: 2.5rem;
            flex-wrap: wrap;
        }

        .welcome-buttons a {
            flex: 1;
            min-width: 150px;
            padding: 1.2rem 2.5rem;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.4s ease;
            text-align: center;
            cursor: pointer;
            border: none;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5);
        }

        .btn-register {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }

        .btn-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(245, 87, 108, 0.5);
        }

        .welcome-image {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .welcome-image img {
            max-width: 100%;
            border-radius: 15px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }

        .welcome-image-placeholder {
            font-size: 6rem;
            animation: float 4s ease-in-out infinite;
            filter: drop-shadow(0 10px 20px rgba(0, 0, 0, 0.2));
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotateZ(-5deg); }
            50% { transform: translateY(-30px) rotateZ(5deg); }
        }

        @media (max-width: 768px) {
            .welcome-container {
                grid-template-columns: 1fr;
                padding: 2rem;
                gap: 2rem;
            }

            .welcome-content {
                text-align: center;
            }

            .welcome-title {
                font-size: 2rem;
            }

            .welcome-subtitle {
                font-size: 1.1rem;
            }

            .welcome-description {
                text-align: center;
                font-size: 0.95rem;
            }

            .welcome-buttons {
                justify-content: center;
            }

            .feature-item {
                justify-content: center;
            }

            .welcome-page {
                background-attachment: scroll;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">L&C Flowershop</div>
                <ul class="nav-links">
                    <li><a href="welcome.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-page">
            <div class="welcome-container">
                <div class="welcome-content">
                    <h1 class="welcome-title">Welcome to<br>L&C Flowershop</h1>
                    <p class="welcome-subtitle">Your Destination for Beautiful Flower Arrangements</p>
                    
                    <p class="welcome-description">
                        Discover the perfect flowers for every occasion. Whether you're celebrating a special moment, expressing your feelings, or simply brightening someone's day, L&C Flowershop has the perfect arrangement for you.
                    </p>

                    <div class="welcome-features">
                        <div class="feature-item">
                            <span class="feature-icon">🌹</span>
                            <span>Premium Quality Fresh Flowers</span>
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon">🎨</span>
                            <span>Custom Arrangement Design</span>
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon">🚚</span>
                            <span>Fast & Reliable Delivery</span>
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon">⭐</span>
                            <span>Trusted by Customers Worldwide</span>
                        </div>
                    </div>

                    <div class="welcome-buttons">
                        <a href="login.php" class="btn-login">Login</a>
                        <a href="register.php" class="btn-register">Register</a>
                    </div>
                </div>

                <div class="welcome-image">
                    <div class="welcome-image-placeholder">💐</div>
                </div>
            </div>
        </section>
    </main>

</body>
</html>
