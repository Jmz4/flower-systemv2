-- Flower Shop Database Dump
-- Database: flower_shop
-- Created for phpMyAdmin Import

-- Drop database if exists (optional - comment out if you want to preserve existing data)
DROP DATABASE IF EXISTS `flower_shop`;

-- Create database
CREATE DATABASE IF NOT EXISTS `flower_shop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `flower_shop`;

-- --------------------------------------------------------
-- Table structure for table `bases`
-- --------------------------------------------------------

CREATE TABLE `bases` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data for table `bases`
INSERT INTO `bases` (`id`, `name`, `price`) VALUES
(1, 'Bouquet', 100.00),
(2, 'Vase', 150.00),
(3, 'Box', 50.00);

-- --------------------------------------------------------
-- Table structure for table `flowers`
-- --------------------------------------------------------

CREATE TABLE `flowers` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 100,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data for table `flowers`
INSERT INTO `flowers` (`id`, `name`, `price`, `stock`, `image`) VALUES
(1, 'Rose', 2.50, 100, NULL),
(2, 'Tulip', 1.80, 150, NULL),
(3, 'Sunflower', 2.00, 80, NULL),
(4, 'Daisy', 1.50, 120, NULL),
(5, 'Lily', 3.00, 90, NULL),
(6, 'Orchid', 4.00, 60, NULL),
(7, 'Carnation', 1.20, 200, NULL),
(8, 'Lavender', 2.20, 110, NULL);

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `username` varchar(50) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `is_admin` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data for table `users`
-- Admin user: username: admin, password: admin123 (bcrypt hashed)
-- Staff user: username: staff, password: staff123 (bcrypt hashed)
INSERT INTO `users` (`id`, `username`, `password`, `email`, `is_admin`, `created_at`) VALUES
(1, 'admin', '$2y$10$LNib8oBZqyn6gOM9t41hF.q5UXYsrgXIJVWgUcJruYlKlZaFeMhCa', 'admin@flowershop.com', 1, CURRENT_TIMESTAMP),
(2, 'staff', '$2y$10$jf16A2ejoT9W3ItjxNPo2um0W0FcWfZ7e5M0GtjM2FfaM4k9YF0W2', 'staff@flowershop.com', 0, CURRENT_TIMESTAMP);

-- --------------------------------------------------------
-- Table structure for table `audit_logs`
-- --------------------------------------------------------

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text,
  `ip_address` varchar(100) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Example audit log
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'seed', 'Initial admin created', 'localhost', CURRENT_TIMESTAMP);

-- --------------------------------------------------------
-- Table structure for table `bouquets`
-- --------------------------------------------------------

CREATE TABLE `bouquets` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `base_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  FOREIGN KEY (`base_id`) REFERENCES `bases` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data for table `bouquets`
INSERT INTO `bouquets` (`id`, `name`, `description`, `price`, `base_id`, `image`) VALUES
(1, 'Romantic Love Bouquet', 'Red roses for that special someone', 35.00, 1, NULL),
(2, 'Happy Birthday Bouquet', 'Colorful mixed flowers for celebrations', 28.00, 1, NULL),
(3, 'Sympathy Bouquet', 'White and soft colored flowers', 32.00, 2, NULL);

-- --------------------------------------------------------
-- Table structure for table `bouquet_items`
-- --------------------------------------------------------

CREATE TABLE `bouquet_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `bouquet_id` int(11) NOT NULL,
  `flower_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  FOREIGN KEY (`bouquet_id`) REFERENCES `bouquets` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`flower_id`) REFERENCES `flowers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data for table `bouquet_items`
INSERT INTO `bouquet_items` (`id`, `bouquet_id`, `flower_id`, `quantity`) VALUES
(1, 1, 1, 12),  -- Romantic: 12 Roses
(2, 1, 5, 5),   -- Romantic: 5 Lilies
(3, 2, 1, 8),   -- Birthday: 8 Roses
(4, 2, 2, 6),   -- Birthday: 6 Tulips
(5, 2, 3, 5),   -- Birthday: 5 Sunflowers
(6, 3, 5, 10),  -- Sympathy: 10 Lilies
(7, 3, 4, 8);   -- Sympathy: 8 Daisies

-- --------------------------------------------------------
-- Table structure for table `orders`
-- --------------------------------------------------------

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `customer_address` text NOT NULL,
  `order_type` enum('delivery','pickup') DEFAULT 'delivery',
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('Pending','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled') DEFAULT 'Pending',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `order_items`
-- --------------------------------------------------------

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` int(11) NOT NULL,
  `item_type` enum('flower','bouquet') NOT NULL,
  `flower_id` int(11) DEFAULT NULL,
  `bouquet_id` int(11) DEFAULT NULL,
  `base_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `custom_style` varchar(30) DEFAULT NULL,
  `custom_notes` text DEFAULT NULL,
  `inspiration_image` varchar(255) DEFAULT NULL,
  `waiver_agreed` tinyint(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`flower_id`) REFERENCES `flowers` (`id`),
  FOREIGN KEY (`bouquet_id`) REFERENCES `bouquets` (`id`),
  FOREIGN KEY (`base_id`) REFERENCES `bases` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ========================================================
-- Database setup completed!
-- Admin Login:
-- Username: admin
-- Password: admin123
-- ========================================================
