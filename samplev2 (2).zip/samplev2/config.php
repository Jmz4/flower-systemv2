<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'flower_shop');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8");

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Role helpers for navigation
function getDashboardUrl() {
    $role = $_SESSION['role'] ?? '';
    if ($role === 'admin') {
        return 'admin.php';
    }
    if ($role === 'staff') {
        return 'staff.php';
    }
    return '';
}

function isAdminOrStaff() {
    $role = $_SESSION['role'] ?? '';
    return in_array($role, ['admin', 'staff'], true);
}

// Use Philippine time for all server-rendered dates
date_default_timezone_set('Asia/Manila');

const ORDER_STATUSES = [
    'Pending',
    'Confirmed',
    'Preparing',
    'Out for Delivery',
    'Delivered',
    'Cancelled'
];

function orderStatusClass($status) {
    return 'badge-' . strtolower(preg_replace('/[^a-z0-9]+/i', '-', $status));
}

function isCustomerCancellableStatus($status) {
    return in_array($status, ['Pending', 'Confirmed'], true);
}

// Function to log user actions
function logAction($action, $details = '') {
    global $conn;
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        if ($ip === '::1' || $ip === '127.0.0.1') {
            $ip = 'localhost';
        }
        $browser = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $shortBrowser = substr($browser, 0, 28);
        $source = substr($ip . ' | ' . $shortBrowser, 0, 45);

        $sql = "INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isss", $user_id, $action, $details, $source);
        $stmt->execute();
        $stmt->close();
    }
}
?>
