<?php
$conn = new mysqli('localhost', 'root', '');
$conn->select_db('flower_shop');
$result = $conn->query('SELECT name, price FROM flowers ORDER BY name');
echo "Flower Prices:\n";
while ($row = $result->fetch_assoc()) {
    echo $row['name'] . ': ₱' . number_format($row['price'], 2) . "\n";
}
echo "\nBouquet Prices:\n";
$result = $conn->query('SELECT name, price FROM bouquets ORDER BY name');
while ($row = $result->fetch_assoc()) {
    echo $row['name'] . ': ₱' . number_format($row['price'], 2) . "\n";
}
$conn->close();
?>