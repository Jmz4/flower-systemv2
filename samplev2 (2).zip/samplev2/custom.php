<?php
require_once 'config.php';

$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');
$orderCount = 0;
$isLoggedIn = isset($_SESSION['user_id']);

// Redirect non-logged-in users to welcome page
if (!$isLoggedIn) {
    header('Location: welcome.php');
    exit;
}

if ($isLoggedIn) {
    $userId = intval($_SESSION['user_id']);
    $orderCountSql = "SELECT COUNT(*) AS count FROM orders WHERE user_id = ?";
    $orderCountStmt = $conn->prepare($orderCountSql);
    $orderCountStmt->bind_param('i', $userId);
    $orderCountStmt->execute();
    $orderCountResult = $orderCountStmt->get_result();
    $orderCountRow = $orderCountResult->fetch_assoc();
    $orderCount = $orderCountRow['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Custom Arrangement - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }

        .cross-nav {
            background: rgba(255, 255, 255, 0.95);
            padding: 1rem 2rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .cross-nav-left {
            font-size: 0.9rem;
            color: #666;
        }

        .cross-nav-link {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.6rem 1.5rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .cross-nav-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .page-header {
            background: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            text-align: center;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        .page-header h1 {
            color: #667eea;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .page-header p {
            color: #666;
            font-size: 1.05rem;
            margin: 0;
        }

        .custom-section {
            background: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .style-selection,
        .custom-details-section {
            margin: 1.5rem 0;
            padding: 1.25rem;
            background: #f9f9f9;
            border-radius: 8px;
        }

        .style-options {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1rem;
        }

        .style-option {
            display: block;
            padding: 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            background: #fff;
            cursor: pointer;
        }

        .style-option:has(input:checked) {
            border-color: #667eea;
            box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.15);
        }

        .style-option input {
            margin-right: 0.5rem;
        }

        .style-option strong {
            color: #667eea;
        }

        .style-option p {
            margin: 0.5rem 0 0;
            color: #666;
            font-size: 0.95rem;
        }

        .upload-panel {
            margin-top: 1rem;
            padding: 1rem;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        .upload-preview {
            display: none;
            margin-top: 1rem;
            align-items: center;
            gap: 1rem;
        }

        .upload-preview img {
            width: 140px;
            height: 140px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid #ddd;
        }

        .waiver {
            margin-top: 1rem;
            padding: 1rem;
            background: #fff8e1;
            border-left: 4px solid #f0ad4e;
            color: #5f4b24;
        }

        .waiver label {
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .validation-message {
            display: none;
            margin: 0.75rem 0;
            padding: 0.75rem;
            border-radius: 4px;
            background: #fde8e8;
            color: #a61b1b;
        }

        @media (max-width: 700px) {
            .style-options {
                grid-template-columns: 1fr;
            }

            .upload-preview {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="choices.php">Home</a></li>
                    <li><a href="reviews.php">Reviews</a></li>
                    <li><a href="about.php">About</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="myorders.php">My Orders <span id="order-count"><?php echo $orderCount; ?></span></a></li>
                    <?php endif; ?>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if ($isLoggedIn): ?>
                        <?php if (isAdminOrStaff()): ?>
                            <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                        <?php endif; ?>
                        <li><a href="logout.php">Logout</a></li>
                        <li class="nav-user">Welcome, <?php echo $username; ?></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <div class="cross-nav">
            <div class="cross-nav-left">
                💭 <strong>Want pre-designed options?</strong>
            </div>
            <a href="bouquets.php" class="cross-nav-link">💐 Browse Pre-Designed Bouquets Instead</a>
        </div>

        <section class="page-header">
            <h1>🎨 Create Your Custom Arrangement</h1>
            <p>Design a unique bouquet just for you! Drag and drop your favorite flowers and choose the perfect base.</p>
        </section>

        <section class="custom-section">
            <div class="custom-arrangement">
                <!-- Base Selection -->
                <div class="form-group">
                    <label for="base">Select Base:</label>
                    <select id="base" onchange="updatePrice()">
                        <option value="">-- Select a base --</option>
                    </select>
                    <span id="basePrice" class="price-display">₱0.00</span>
                </div>

                <section class="style-selection" aria-labelledby="styleSelectionHeading">
                    <h2 id="styleSelectionHeading">Style Selection</h2>
                    <div class="style-options">
                        <label class="style-option">
                            <input type="radio" name="arrangementStyle" value="flowers" checked onchange="handleStyleSelection()">
                            <strong>Select Your Flowers</strong> <span>(Stylist’s Choice)</span>
                            <p>Select your favorite flowers, and our expert team at L&amp;C Online Flower Shop will artfully craft them into a one-of-a-kind arrangement.</p>
                        </label>
                        <label class="style-option">
                            <input type="radio" name="arrangementStyle" value="inspiration" onchange="handleStyleSelection()">
                            <strong>Upload an Inspiration Photo</strong> <span>(Custom Peg)</span>
                            <p>Have a specific look in mind? Upload your reference images or design pegs, and we will match your desired aesthetic as closely as possible.</p>
                        </label>
                    </div>

                    <div id="inspirationPanel" class="upload-panel" hidden>
                        <div class="form-group">
                            <label for="inspirationImage">Upload an inspiration image (JPG, JPEG, or PNG; maximum 5 MB)</label>
                            <input type="file" id="inspirationImage" accept="image/jpeg,image/png" onchange="handleInspirationImage(this)">
                        </div>
                        <div id="uploadError" class="validation-message" role="alert"></div>
                        <div id="uploadPreview" class="upload-preview">
                            <img id="inspirationPreview" src="" alt="Inspiration image preview">
                            <button type="button" class="btn btn-danger" onclick="removeInspirationImage()">Remove Image</button>
                        </div>
                        <div class="waiver">
                            <strong>Customization &amp; Substitution Waiver:</strong>
                            <p>Reference images submitted by the customer are used strictly for visual inspiration and guidance. Due to variations in regional availability, seasonal bloom changes, and natural differences in living flowers, L&amp;C Online Flower Shop does not guarantee an exact duplicate of any reference image. L&amp;C Online Flower Shop reserves the right to substitute stems or vessel components of equal or greater value to preserve the integrity and aesthetic of the final arrangement.</p>
                            <label><input type="checkbox" id="waiverAgreement"> <span>I have read and agree to the customization terms.</span></label>
                        </div>
                    </div>
                </section>

                <!-- Occasion Selection -->
                <div class="form-group">
                    <label for="occasion">Occasion (Get Suggestions):</label>
                    <select id="occasion" onchange="suggestFlowers()">
                        <option value="">-- Select occasion --</option>
                        <option value="birthday">Birthday</option>
                        <option value="anniversary">Anniversary</option>
                        <option value="funeral">Funeral</option>
                    </select>
                </div>

                <!-- Suggested Flowers Display -->
                <div id="suggestionBox" class="suggestion-box" style="display:none;">
                    <p id="suggestionText"></p>
                </div>

                <!-- Drag & Drop Section -->
                <div class="drag-drop-section">
                    <h3>💐 Drag Flowers to Your Arrangement</h3>
                    
                    <!-- Flower Gallery -->
                    <div class="flower-gallery">
                        <div class="gallery-label">Available Flowers (Drag to arrange):</div>
                        <div id="flowerGallery" class="flowers-grid"></div>
                    </div>

                    <!-- Canvas/Drop Zone -->
                    <div id="arrangementCanvas" class="arrangement-canvas">
                        <div class="canvas-placeholder">👈 Drag flowers here</div>
                        <div id="flowerArrangement" class="flower-arrangement-display"></div>
                    </div>
                </div>

                <!-- Arrangement Items List -->
                <div class="arrangement-items">
                    <h3>Your Arrangement Items</h3>
                    <div id="arrangementList" class="items-list"></div>
                    <button onclick="clearArrangement()" class="btn btn-danger" style="margin-top: 0.5rem; width: 100%;">Clear All</button>
                </div>

                <!-- Price Calculation -->
                <div class="price-section">
                    <div class="price-row">
                        <span>Base Price:</span>
                        <span id="totalBasePrice">₱0.00</span>
                    </div>
                    <div class="price-row">
                        <span>Flowers Price:</span>
                        <span id="totalFlowersPrice">₱0.00</span>
                    </div>
                    <div class="price-row total">
                        <span>Total Price:</span>
                        <span id="totalPrice">₱0.00</span>
                    </div>
                </div>

                <section class="custom-details-section">
                    <h2>Additional Notes / Special Requests</h2>
                    <div class="form-group">
                        <label for="arrangementNotes">Tell us what you have in mind (optional)</label>
                        <textarea id="arrangementNotes" rows="6" placeholder="Describe how you want your flower arrangement to look or any special requests you have..."></textarea>
                    </div>
                </section>

                <div id="customValidationMessage" class="validation-message" role="alert"></div>
                <button onclick="addCustomToCart()" class="btn btn-success btn-full">Proceed to Cart</button>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 L&C Flowershop. All rights reserved. | Contact: info@flowershop.com</p>
    </footer>

    <script>
        window.cartUserKey = <?php echo json_encode($isLoggedIn ? 'cart_user_' . intval($_SESSION['user_id']) : 'cart_guest'); ?>;
    </script>
    <script src="script.js?v=2"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadBases();
            loadFlowers();
            updateCartCount();
            loadArrangement();
        });
    </script>
</body>
</html>
