<?php
require_once 'config.php';

$username = htmlspecialchars($_SESSION['username'] ?? 'Guest');
$orderCount = 0;
$isLoggedIn = isset($_SESSION['user_id']);

// Redirect non-logged-in users to welcome page
if (!$isLoggedIn) {
    header('Location: welcome.php');
    exit;
}

if ($isLoggedIn) {
    $userId = intval($_SESSION['user_id']);
    $orderCountSql = "SELECT COUNT(*) AS count FROM orders WHERE user_id = ?";
    $orderCountStmt = $conn->prepare($orderCountSql);
    $orderCountStmt->bind_param('i', $userId);
    $orderCountStmt->execute();
    $orderCountResult = $orderCountStmt->get_result();
    $orderCountRow = $orderCountResult->fetch_assoc();
    $orderCount = $orderCountRow['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pre-Designed Bouquets - Flower Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('flowerimage/background.png') !important;
            background-size: cover !important;
            background-position: center !important;
            background-attachment: fixed !important;
        }

        .cross-nav {
            background: rgba(255, 255, 255, 0.95);
            padding: 1rem 2rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .cross-nav-left {
            font-size: 0.9rem;
            color: #666;
        }

        .cross-nav-link {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.6rem 1.5rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .cross-nav-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .page-header {
            background: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            text-align: center;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        .page-header h1 {
            color: #667eea;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .page-header p {
            color: #666;
            font-size: 1.05rem;
            margin: 0;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <img src="./flowerimage/lc-logo.jpg" alt="L&C Flowershop Logo" style="width: 42px; height: 42px; vertical-align: middle; border-radius: 999px; margin-right: 0.6rem; object-fit: cover;" onerror="this.src='./flowerimage/flowersrose.jfif'">
                    L&C Flowershop
                </div>
                <ul class="nav-links">
                    <li><a href="choices.php">Home</a></li>
                    <li><a href="reviews.php">Reviews</a></li>
                    <li><a href="about.php">About</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="myorders.php">My Orders <span id="order-count"><?php echo $orderCount; ?></span></a></li>
                    <?php endif; ?>
                    <li><a href="cart.php">🛒 Cart <span id="cart-count">0</span></a></li>
                    <?php if ($isLoggedIn): ?>
                        <?php if (isAdminOrStaff()): ?>
                            <li><a href="<?php echo getDashboardUrl(); ?>">Back to Dashboard</a></li>
                        <?php endif; ?>
                        <li><a href="logout.php">Logout</a></li>
                        <li class="nav-user">Welcome, <?php echo $username; ?></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <main class="container">
        <div class="cross-nav">
            <div class="cross-nav-left">
                💭 <strong>Want something different?</strong>
            </div>
            <a href="custom.php" class="cross-nav-link">🎨 Create Custom Arrangement Instead</a>
        </div>

        <section class="page-header">
            <h1>💐 Pre-Designed Bouquets</h1>
            <p>Handcrafted arrangements perfect for any occasion. Browse our collection and add your favorite to your cart.</p>
        </section>

        <section class="pre-designed-bouquets" style="background: transparent;">
            <div id="bouquetsList" class="bouquets-grid"></div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 L&C Flowershop. All rights reserved. | Contact: info@flowershop.com</p>
    </footer>

    <script>
        window.cartUserKey = <?php echo json_encode($isLoggedIn ? 'cart_user_' . intval($_SESSION['user_id']) : 'cart_guest'); ?>;
    </script>
    <script src="script.js?v=2"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadBouquets();
            updateCartCount();
        });
    </script>
</body>
</html>
