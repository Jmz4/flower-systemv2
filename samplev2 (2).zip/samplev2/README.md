# 🌸 Web-Based Custom Flower Arrangement and Ordering System

A complete beginner-friendly flower shop application built with HTML, CSS, JavaScript, PHP, and MySQL.

## Features

### 1. ✨ Custom Flower Arrangement
- Select from available bases (Bouquet, Vase, Box)
- Choose flowers and quantities
- Add/remove items from arrangement
- Real-time price calculation

### 2. 💰 Real-Time Price Calculation
- Automatic total price updates using JavaScript
- Formula: (flower price × quantity) + base price
- Dynamic price display for each item

### 3. 💐 Pre-Designed Bouquets
- 3 ready-made bouquet options:
  - Romantic Love Bouquet ($35.00)
  - Happy Birthday Bouquet ($28.00)
  - Sympathy Bouquet ($32.00)
- Fixed flowers and prices for each bouquet

### 4. 🎂 Occasion-Based Suggestions
- Dropdown for occasion selection (Birthday, Anniversary, Funeral)
- Recommended flowers display based on selection
- Helpful suggestions for each occasion

### 5. 🛒 Online Ordering System
- Add items to cart (localStorage-based)
- Checkout form with:
  - Customer name, email, phone
  - Delivery address
  - Delivery or Pickup option
- Order summary display
- Order confirmation with ID

### 6. 👨‍💼 Admin Panel
- View all orders with details
- Update order status (pending, preparing to ship, delivered, completed, cancelled)
- Add/edit/delete flower products
- View order history
- Manage product prices and names
- **NEW:** View activity history of all staff and admin actions

### 7. 👷 Staff Account
- **NEW:** Limited access account for staff members
- Can view and update order statuses
- Can view product catalog (read-only)
- Cannot add/edit/delete products or access inventory management
- All actions are logged for admin review

### 8. 📊 Activity Audit System
- **NEW:** Complete audit trail of all admin and staff actions
- Logs include: order updates, product changes, user actions, timestamps, and IP addresses
- Admin can view history of all staff activities
- Ensures accountability and security

### 9. 📱 Inventory Management
- Stock tracking for each flower
- Stock deduction after order placement
- Out of stock prevention
- Low stock warnings in admin panel
- Stock level indicators (In Stock, Low Stock, Out of Stock)

## File Structure

```
sample3/
├── config.php              # Database configuration
├── setup_db.php            # Database setup script (run once)
├── index.php               # Main storefront page
├── cart.php                # Shopping cart page
├── checkout.php            # Checkout page
├── login.php               # Login page for admin
├── admin.php               # Admin panel dashboard
├── logout.php              # Logout functionality
├── api.php                 # API endpoints (AJAX requests)
├── style.css               # CSS styling
├── script.js               # JavaScript functionality
└── README.md               # This file
```

## Installation Steps

### 1. Prerequisites
- PHP 7.0 or higher
- MySQL/MariaDB
- A local server (XAMPP, WAMP, or LAMP)

### 2. Setup Instructions

#### Step 1: Copy Files
Copy all files to your web server's htdocs directory:
- For XAMPP: `C:\xampp\htdocs\flower_shop\`
- For WAMP: `C:\wamp\www\flower_shop\`

#### Step 2: Create Database
1. Open your browser and navigate to phpMyAdmin
2. Alternatively, run the setup script:
   - Open `http://localhost/flower_shop/setup_db.php` in your browser
   - This will automatically create the database and all tables

Or manually create the database:
```sql
CREATE DATABASE flower_shop;
```

#### Step 3: Verify Configuration
Edit `config.php` if needed to match your database credentials:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'flower_shop');
```

#### Step 4: Access the Application
- **Storefront**: http://localhost/flower_shop/index.php
- **Admin Panel**: http://localhost/flower_shop/admin.php
- **Cart**: http://localhost/flower_shop/cart.php
- **Login**: http://localhost/flower_shop/login.php

## Database Schema

### Tables

1. **users** - Admin users
   - id, username, password, email, is_admin, created_at

2. **bases** - Flower arrangement bases
   - id, name, price

3. **flowers** - Individual flower products
   - id, name, price, stock, image

4. **bouquets** - Pre-designed bouquets
   - id, name, description, price, base_id, image

5. **bouquet_items** - Flowers in each bouquet
   - id, bouquet_id, flower_id, quantity

6. **orders** - Customer orders
   - id, user_id, customer_name, customer_email, customer_phone, customer_address, order_type, total_price, status, created_at

7. **order_items** - Items in each order
   - id, order_id, item_type, flower_id, bouquet_id, base_id, quantity, unit_price, subtotal

## How to Use

### For Customers

#### Creating Custom Arrangements
1. Go to the home page
2. Select a base (Bouquet, Vase, or Box)
3. Optionally select an occasion for suggestions
4. Choose flowers and quantities
5. Click "Add to Arrangement"
6. Review your items and click "Add Custom Arrangement to Cart"

#### Ordering Pre-Designed Bouquets
1. Browse the bouquets on the right side of the page
2. Click "Add to Cart" on any bouquet
3. Proceed to checkout

#### Checkout
1. Click the cart icon in the navbar
2. Fill in delivery details:
   - Full Name
   - Email
   - Phone Number
   - Delivery Address
   - Choose Delivery or Pickup
3. Review order summary
4. Click "Place Order"
5. You'll receive an order ID confirmation

### For Admin Users

#### View Orders
1. Login with admin credentials
2. Navigate to Orders section
3. View all customer orders
4. Click "Edit" to update order status

#### Manage Products
1. Go to Products section
2. Add new products using the form
3. Edit existing products' names, prices, and stock

#### Monitor Inventory
1. Go to Inventory section
2. View all products with current stock levels
3. See stock status indicators (In Stock, Low Stock, Out of Stock)

## Sample Data

The system comes with:
- **8 Flower Types**: Rose, Tulip, Sunflower, Daisy, Lily, Orchid, Carnation, Lavender
- **3 Base Types**: Bouquet, Vase, Box
- **3 Pre-Designed Bouquets**: Romantic, Birthday, Sympathy

## Features Details

### Price Calculation
- **Custom Arrangement**: Base Price + (Flower Price × Quantity) for each flower
- **Pre-Designed Bouquets**: Fixed price as displayed
- **Total**: Sum of all items in cart

### Inventory Management
- Stock automatically deducts when order is placed
- System prevents ordering more than available stock
- Admin can see stock levels at a glance
- Low stock warning when stock ≤ 20 items

### Order Statuses
- **Pending** - Order just received
- **Preparing to Ship** - Order being prepared for shipment
- **Delivered** - Order delivered to customer
- **Completed** - Order completed
- **Cancelled** - Order cancelled

### Occasion-Based Recommendations
- **Birthday**: Bright colors (Tulips, Sunflowers, Daisies)
- **Anniversary**: Romantic (Red Roses, Lilies)
- **Funeral**: Soft colors (White Lilies, Daisies)

## Security Features

- Password hashing using bcrypt
- Session management for admin authentication
- Prepared statements to prevent SQL injection
- Input validation on all forms
- Cart stored in browser localStorage (client-side)

## Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Troubleshooting

### Database Connection Error
- Verify MySQL is running
- Check credentials in `config.php`
- Ensure database exists

### Can't Login
- **Admin Account:**
  - Default username: `admin`
  - Default password: `admin123`
- **Staff Account:**
  - Default username: `staff`
  - Default password: `staff123`
- Check that setup_db.php was run successfully

### Cart Not Working
- Check browser console for JavaScript errors
- Clear browser cache and localStorage
- Ensure JavaScript is enabled

### Stock Deduction Issues
- Verify MySQL transactions are supported
- Check database permissions
- Ensure flowers have stock > 0

## Customization

### Add New Flowers
1. Go to Admin Panel → Products
2. Fill in product name, price, and stock
3. Click "Add Product"

### Change Base Prices
- Edit through Admin Panel Products section
- Or directly in database `bases` table

### Modify Pre-Designed Bouquets
- Edit in database `bouquets` table
- Or use a separate admin form (can be added)

### Customize Styles
- Edit `style.css` for colors, fonts, and layout
- Colors use purple (#667eea) theme

## Performance Optimization

- Cart stored in localStorage (fast client-side access)
- AJAX calls for dynamic data loading
- Optimized SQL queries with proper indexing
- CSS grid for responsive layouts

## Future Enhancements

- Payment gateway integration (Stripe, PayPal)
- Email notifications for orders
- User registration system
- Order tracking for customers
- Product image uploads
- Rating and reviews system
- Seasonal promotions
- Mobile app version

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review file permissions
3. Check browser console for errors
4. Verify PHP and MySQL versions

## License

This project is free to use for educational purposes.

## Credits

Built as a beginner-friendly flower shop ordering system demonstration.

---

**Happy Flower Shopping! 🌸💐🌹**
